"""Offline integration checks for the Windows Tk interface (run with a display)."""
from pathlib import Path
import sys,time,os,tempfile
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from tracker import App
from bossdata import BY_KEY
with tempfile.TemporaryDirectory() as d:
 os.environ['APPDATA']=d
 a=App();a.withdraw();a.update()
 assert a.version if hasattr(a,'version') else True
 boss=BY_KEY['Verteron:High Commander Lagta']
 a.selected_boss=boss
 a.var_boss_minutes.set('2')
 a.mark_kill()
 assert len(a.state['kills'])==1
 a.toggle_favorite()
 assert boss.key in a.state['favorites']
 a.show_page('Overview');a.update()
 assert boss.name in a.ov_bc.itemcget(a.ov_boss_id,'text')
 tree_row=next((row for row,b in a.ov_boss_rows.items() if b.key==boss.key),None)
 assert tree_row is not None
 before=a.ov_boss_tree.set(tree_row,'timer')
 assert before.startswith('00:01') or before.startswith('00:02'),before
 for _ in range(16):time.sleep(.09);a.update()
 after=a.ov_boss_tree.set(tree_row,'timer')
 assert before!=after,(before,after)
 a.show_page('Events');a.update()
 row=next(row for row,e in a._event_row.items() if e['when']>time.time()+30)
 before=a.event_tree.set(row,'left')
 for _ in range(15):time.sleep(.09);a.update()
 after=a.event_tree.set(row,'left')
 assert before!=after,(before,after)
 a.show_page('Map');a.update()
 a.show_page('Updates');a.update()
 a.exit()
 # Saved data survives relaunch and preserves favorites.
 a=App();a.withdraw();a.update()
 assert boss.key in a.state['favorites']
 assert len(a.state['kills'])==1
 a.exit()
print('GUI countdown, favorites, saved settings, and navigation tests passed')
