from pathlib import Path
import sys,os,tempfile
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from tracker import App
with tempfile.TemporaryDirectory() as d:
 os.environ['APPDATA']=d
 app=App()
 app.withdraw()
 app.toggle_mini();app.update()
 assert app.mini and len(app.mini_rows)==4
 app.refresh_mini(__import__('time').time())
 app.notify('LIVE NOW • TEST','Shugo Festival started!',True)
 app.update()
 assert app.toast and app.toast.winfo_exists()
 app.toast.destroy()
 app.toggle_mini()
 app.exit()
print('Overlay + popup tests passed')
