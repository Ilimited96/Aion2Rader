from pathlib import Path
import sys,time
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from engine import clock
assert clock(60)=='00:01:00'
assert clock(59)=='00:00:59'
assert clock(86400+3723)=='1d 01:02:03'
assert clock(2*86400+1)=='2d 00:00:01'
print('V2.1 countdown unit tests passed')
