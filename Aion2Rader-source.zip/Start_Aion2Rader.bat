@echo off
setlocal
cd /d "%~dp0"
title Aion2Rader - Update V2.1
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 tracker.py
) else (
  python tracker.py
)
if errorlevel 1 (
  echo.
  echo Could not start Aion2Rader. Make sure you installed Python from python.org.
  pause
)
endlocal
