"""Aion2Rader Update V2.1 — unofficial AION 2 Global countdown companion.
Offline schedules; opt-in HTTPS release updates. Python standard library only.
"""
from __future__ import annotations
import json, os, shutil, subprocess, sys, tempfile, threading, time, uuid, webbrowser
from datetime import datetime, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from engine import DEFS, REGIONS, occurrences, clock, stamp, ics
from alerts import events_just_started
from bossdata import BOSSES, BY_KEY, MAP_LINKS
from updater import check_manifest, download_package, safe_extract_package

VERSION='2.1.0'
APP='Aion2Rader'
BG='#06101F'; PANEL='#0B2035'; CARD='#132943'; CARD2='#173553'
GOLD='#E4BF77'; GOLD2='#A67B42'; BLUE='#74C9EE'; TEXT='#E9F1F9'
MUTED='#92AABE'; GREEN='#7BEBB2'; RED='#FF918F'; BORDER='#7B6039'
FONT='Segoe UI'
BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))


def directory():
    p=Path(os.environ.get('APPDATA',str(Path.home()/'.config')))/APP
    p.mkdir(parents=True,exist_ok=True)
    return p

def safe_load(path):
    try:
        a=json.loads(path.read_text(encoding='utf-8'))
        return a if isinstance(a,dict) else {}
    except (OSError, ValueError):return {}

def truth(state,key,default=True):return bool(state.get(key,default))

def display_time(ts):return datetime.fromtimestamp(ts).strftime('%a %d %b · %H:%M')

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'{APP}  |  Update V2.1  |  Elyos')
        self.configure(bg=BG)
        self.geometry('1480x890')
        self.minsize(1100,705)
        try:self.iconbitmap(str(BASE/'assets/aion2rader.ico'))
        except tk.TclError:pass
        self.home=directory();self.settings_file=self.home/'settings.json'
        if not self.settings_file.exists():
            old=Path(os.environ.get('APPDATA',str(Path.home()/'.config')))/'Aion2EventRadar/settings.json'
            if old.is_file():shutil.copy2(old,self.settings_file)
        self.state=safe_load(self.settings_file)
        self.state.setdefault('favorites',[])
        self.state.setdefault('kills',[])
        self.state.setdefault('extras',[])
        self.state.setdefault('shifts',{})
        self.state.setdefault('muted',[])
        self.state.setdefault('region','Europe (EU)')
        self.state.setdefault('lead',10)
        # Support Update V1.1 settings keys and preserve them.
        if 'alert' not in self.state:self.state['alert']=self.state.get('alerts',True)
        # Migrate old boss timers to keyed Elyos entries where the name is unique.
        for old_k in self.state['kills']:
            if 'boss_key' in old_k:continue
            raw=str(old_k.get('name','')).split(' - ')[-1]
            found=next((b for b in BOSSES if b.name==raw),None)
            if found:old_k['boss_key']=found.key
        self.page='Overview';self.events=[];self.selected_boss=None;self.rows={}
        self.last_calc=0;self.last_alert_poll=time.time();self.last_redraw=0;self.last_clock_second=None
        self.seen=set();self.toast=None;self.mini=None;self.pending_update=None
        self.var_region=tk.StringVar(value=self.state['region'] if self.state['region'] in REGIONS else 'Europe (EU)')
        self.var_alert=tk.BooleanVar(value=truth(self.state,'alert',truth(self.state,'alerts',True)))
        self.var_live=tk.BooleanVar(value=truth(self.state,'live_alerts'))
        self.var_sound=tk.BooleanVar(value=truth(self.state,'sound'))
        self.var_fav_alert=tk.BooleanVar(value=truth(self.state,'favorite_alerts'))
        self.var_top=tk.BooleanVar(value=truth(self.state,'on_top',False))
        self.var_lead=tk.StringVar(value=str(self.state.get('lead',10)))
        self.var_boss_filter=tk.StringVar(value='All Elyos bosses')
        self.var_boss_search=tk.StringVar(value='')
        self.var_event_filter=tk.StringVar(value='All events')
        self.var_event_search=tk.StringVar(value='')
        self.var_period=tk.StringVar(value='Next 24 hours')
        self.var_update_url=tk.StringVar(value=str(self.state.get('update_url','')))
        self.var_update_status=tk.StringVar(value='No update source configured.' if not self.var_update_url.get() else 'Ready to check for updates.')
        self.var_boss_minutes=tk.StringVar(value='')
        self._art={};self._styles();self._chrome();self.show_page('Overview')
        self.attributes('-topmost',self.var_top.get())
        self.protocol('WM_DELETE_WINDOW',self.exit)
        self.recalculate();self.last_redraw=time.time();self.after(200,self.tick)

    def save(self):
        self.state.update(region=self.var_region.get(),alert=self.var_alert.get(),alerts=self.var_alert.get(),
              live_alerts=self.var_live.get(),sound=self.var_sound.get(),favorite_alerts=self.var_fav_alert.get(),
              on_top=self.var_top.get(),lead=int(self.var_lead.get()),update_url=self.var_update_url.get().strip())
        try:
            tmp=self.settings_file.with_suffix('.tmp')
            tmp.write_text(json.dumps(self.state,indent=2),encoding='utf-8');tmp.replace(self.settings_file)
        except OSError as e:messagebox.showerror('Could not save settings',str(e),parent=self)

    def _styles(self):
        sty=ttk.Style(self);sty.theme_use('clam')
        sty.configure('R.Treeview',background=PANEL,fieldbackground=PANEL,foreground=TEXT,
                     rowheight=37,font=(FONT,10),borderwidth=0)
        sty.configure('R.Treeview.Heading',background=CARD2,foreground=GOLD,
                      font=(FONT,9,'bold'),padding=(7,11),relief='flat')
        sty.map('R.Treeview',background=[('selected','#2B5471')],foreground=[('selected','#FFFFFF')])
        sty.configure('R.TCombobox',foreground=TEXT,background=CARD2,fieldbackground=CARD,
                      arrowcolor=GOLD,bordercolor=BORDER,padding=5)
        sty.map('R.TCombobox',fieldbackground=[('readonly',CARD)],foreground=[('readonly',TEXT)])
        sty.configure('R.Vertical.TScrollbar',background=CARD2,troughcolor=BG)

    def label(self,parent,value,size=10,color=TEXT,bold=False,bg=None,**kw):
        return tk.Label(parent,text=value,fg=color,bg=bg or parent.cget('bg'),
                         font=(FONT,size,'bold' if bold else 'normal'),**kw)
    def panel(self,parent,color=PANEL,**kw):return tk.Frame(parent,bg=color,highlightbackground=GOLD2,highlightthickness=1,**kw)
    def button(self,parent,title,callback,primary=False,compact=False):
        return tk.Button(parent,text=title,command=callback,bg=GOLD if primary else CARD2,
            fg=BG if primary else TEXT,activebackground='#F9DC9E' if primary else '#2A536D',
            activeforeground=BG if primary else TEXT,relief='flat',bd=0,
            padx=14,pady=7 if compact else 10,font=(FONT,9,'bold'),cursor='hand2')
    def entry(self,parent,var,width=30):
        return tk.Entry(parent,textvariable=var,bg=CARD,fg=TEXT,insertbackground=GOLD,
                        relief='flat',highlightbackground=BORDER,highlightthickness=1,width=width,
                        font=(FONT,10))
    def combo(self,parent,var,values,width=20):
        return ttk.Combobox(parent,textvariable=var,values=values,state='readonly',width=width,style='R.TCombobox')
    def check(self,parent,title,var,fn=None):
        return tk.Checkbutton(parent,text=title,variable=var,command=fn or self.save,fg=TEXT,bg=parent.cget('bg'),
                              selectcolor=BG,activebackground=parent.cget('bg'),activeforeground=GOLD,
                              font=(FONT,10))
    def section(self,parent,title,subtitle=''):
        self.label(parent,title,16,GOLD,True).pack(anchor='w',pady=(0,4))
        if subtitle:self.label(parent,subtitle,9,MUTED).pack(anchor='w',pady=(0,15))
    def art(self,name):
        """Keep Tk images alive and read only bundled, generated artwork."""
        if name not in self._art:
            try:self._art[name]=tk.PhotoImage(file=str(BASE/'assets'/name))
            except tk.TclError:self._art[name]=None
        return self._art[name]

    def ornate_heading(self,parent,title,subtitle=''):
        head=tk.Frame(parent,bg=BG)
        head.pack(fill='x',pady=(0,10))
        self.label(head,'✦  '+title.upper(),16,GOLD,True).pack(side='left')
        if subtitle:self.label(head,subtitle,9,MUTED).pack(side='right')
        tk.Frame(parent,bg=GOLD2,height=1).pack(fill='x',pady=(0,12))

    def _chrome(self):
        header=tk.Canvas(self,bg='#071729',height=112,highlightthickness=0)
        header.pack(fill='x');header.pack_propagate(False)
        header.create_image(0,0,anchor='nw',image=self.art('fantasy_header.png'))
        header.create_text(27,19,text='✦',fill=GOLD,font=(FONT,30,'bold'),anchor='nw')
        header.create_text(79,21,text='A I O N 2 R A D E R',fill='#F3D59C',font=(FONT,26,'bold'),anchor='nw')
        header.create_text(83,66,text='E V E N T   R A D A R     ✦     E L Y O S',fill=BLUE,font=(FONT,10,'bold'),anchor='nw')
        self.now_label=self.label(header,'Your local time —',10,TEXT,True,bg='#09192A')
        header.create_window(1440,36,window=self.now_label,anchor='ne',tags='clock')
        header.bind('<Configure>',lambda e:header.coords('clock',e.width-27,36))
        header.create_line(0,110,2000,110,fill=GOLD2,width=2)
        nav=tk.Frame(self,bg='#0A1C31',height=51)
        nav.pack(fill='x');nav.pack_propagate(False)
        self.nav_buttons={}
        for name,icon in [('Overview','✧'),('Events','✦'),('World Bosses','♛'),('Calendar','▦'),('Map','⌖'),('Settings','⚙'),('Updates','↓')]:
            b=tk.Button(nav,text=f'{icon}  {name}',bg='#0A1C31',fg=TEXT,activebackground=CARD2,
                       activeforeground=GOLD,relief='flat',bd=0,highlightthickness=0,
                       font=(FONT,10,'bold'),cursor='hand2',padx=20,pady=10,
                       command=lambda x=name:self.show_page(x))
            b.pack(side='left',padx=(13 if name=='Overview' else 2,0),pady=4)
            self.nav_buttons[name]=b
        self.label(nav,'🪽  ELYOS  ·  GLOBAL',10,GOLD,True,bg='#0A1C31').pack(side='right',padx=22)
        tk.Frame(self,bg=GOLD2,height=1).pack(fill='x')
        self.body=tk.Frame(self,bg=BG)
        self.body.pack(fill='both',expand=True,padx=16,pady=(14,7))
        bottom=tk.Frame(self,bg='#0A1B2B',height=38)
        bottom.pack(fill='x');bottom.pack_propagate(False)
        self.status=self.label(bottom,'Community schedules • Not connected to AION 2 servers • Verify in game',9,MUTED,bg='#0A1B2B')
        self.status.pack(side='left',padx=21,pady=8)
        self.label(bottom,'UPDATE V2.1',9,GOLD,True,bg='#0A1B2B').pack(side='right',padx=14)
        self.button(bottom,'Mini overlay',self.toggle_mini,compact=True).pack(side='right',pady=3)

    def hero_card(self,parent,kind):
        outer=self.panel(parent, '#071B30')
        c=tk.Canvas(outer,bg='#0B1D33',height=194,highlightthickness=0,cursor='hand2')
        c.pack(fill='both',expand=True)
        art=self.art('hero_'+kind+'.png')
        if art:
            bgid=c.create_image(0,0,image=art,anchor='nw')
            def bg_resize(e):
                sm=self.art('hero_'+kind+'_sm.png')
                if sm and e.width<430:c.itemconfigure(bgid,image=sm)
                else:c.itemconfigure(bgid,image=art)
            c.bind('<Configure>',bg_resize)
        else:c.create_rectangle(0,0,900,190,fill='#163450',outline='')
        c.create_text(19,16,text='✦  '+('NEXT EVENT' if kind=='festival' else 'NEXT FAVORITE WORLD BOSS'),
                      fill=GOLD,font=(FONT,10,'bold'),anchor='nw')
        title=c.create_text(20,62,text='Loading…',font=(FONT,16,'bold'),fill=TEXT,anchor='nw',width=355)
        count=c.create_text(20,104,text='00:00:00',font=(FONT,29,'bold'),fill=BLUE,anchor='nw')
        sub=c.create_text(20,158,text='Community schedule',font=(FONT,9),fill='#D1E7F3',anchor='nw',width=400)
        c.bind('<Button-1>',lambda e:self.show_page('Events' if kind=='festival' else 'World Bosses'))
        return outer,c,title,count,sub

    def page_overview(self):
        # Matches the approved reference: two large illustrated cards, event lists,
        # LIVE cards, and an integrated Elyos favorites/boss panel.
        stage=tk.Frame(self.body,bg=BG)
        stage.pack(fill='both',expand=True)
        stage.grid_columnconfigure(0,weight=9,uniform='dashboard')
        stage.grid_columnconfigure(1,weight=5,uniform='dashboard')
        stage.grid_rowconfigure(0,weight=1)
        left=tk.Frame(stage,bg=BG)
        left.grid(row=0,column=0,sticky='nsew',padx=(0,12))
        right=tk.Frame(stage,bg=BG)
        right.grid(row=0,column=1,sticky='nsew')

        heroes=tk.Frame(left,bg=BG)
        heroes.pack(fill='x',pady=(1,13))
        heroes.grid_columnconfigure(0,weight=1,uniform='heroes');heroes.grid_columnconfigure(1,weight=1,uniform='heroes')
        ev, self.ov_ec, self.ov_event_id,self.ov_timer_id,self.ov_event_desc_id=self.hero_card(heroes,'festival')
        ev.grid(row=0,column=0,sticky='nsew',padx=(0,6))
        bo, self.ov_bc, self.ov_boss_id,self.ov_boss_time_id,self.ov_boss_desc_id=self.hero_card(heroes,'boss')
        bo.grid(row=0,column=1,sticky='nsew',padx=(6,0))
        self.ornate_heading(left,'Upcoming events','LIVE NOW marked in green')
        lower=tk.Frame(left,bg=BG)
        lower.pack(fill='both',expand=True)
        lower.grid_columnconfigure(0,weight=12,uniform='lower')
        lower.grid_columnconfigure(1,weight=8,uniform='lower')
        lower.grid_rowconfigure(0,weight=1)
        upcoming=self.panel(lower);upcoming.grid(row=0,column=0,sticky='nsew',padx=(0,7))
        tb=tk.Frame(upcoming,bg=PANEL);tb.pack(fill='x',padx=11,pady=(9,4))
        self.label(tb,'EVENT TIMELINE',10,GOLD,True).pack(side='left')
        self.button(tb,'All events →',lambda:self.show_page('Events'),compact=True).pack(side='right')
        self.ov_tree=self.row_tree(upcoming,[('name','EVENT',174),('start','LOCAL TIME',102),('in','STARTS IN',95)],10)
        live=self.panel(lower)
        live.grid(row=0,column=1,sticky='nsew',padx=(7,0))
        self.label(live,'✦  LIVE EVENTS',10,GOLD,True).pack(anchor='w',padx=13,pady=(14,12))
        self.live_tiles=[]
        for art in ['icon_Festival.png','icon_Rift.png']:
            p=self.panel(live,CARD)
            p.pack(fill='x',padx=11,pady=(0,9))
            pic=self.art(art)
            if pic:tk.Label(p,image=pic,bg=CARD).pack(side='left',padx=5,pady=5)
            info=tk.Frame(p,bg=CARD);info.pack(side='left',fill='both',expand=True,padx=8,pady=7)
            nm=self.label(info,'Checking events…',10,TEXT,True,wraplength=150,justify='left')
            nm.pack(anchor='w')
            tim=self.label(info,'',10,GREEN,True);tim.pack(anchor='w',pady=(8,0))
            self.live_tiles.append((nm,tim))
        self.label(live,'NEXT ACTIVITIES',10,GOLD,True).pack(anchor='w',padx=13,pady=(11,9))
        self.ov_next_text=self.label(live,'',10,TEXT,justify='left',wraplength=245)
        self.ov_next_text.pack(anchor='w',padx=13,pady=(0,8))
        self.button(live,'Test LIVE alert',lambda:self.notify('LIVE NOW • TEST','Example Aion2Rader notification',True),compact=True).pack(anchor='w',padx=12,pady=(3,11))

        hdr=tk.Frame(right,bg=BG);hdr.pack(fill='x',pady=(1,7))
        self.label(hdr,'♛  WORLD BOSSES',15,GOLD,True).pack(side='left')
        self.label(hdr,'ELYOS ONLY',9,GREEN,True).pack(side='right')
        filt=tk.Frame(right,bg=BG);filt.pack(fill='x',pady=(0,11))
        self.ov_boss_filter=tk.StringVar(value='All Elyos bosses')
        cb=self.combo(filt,self.ov_boss_filter,['All Elyos bosses','★ Favorites only','Verteron only','Eltnen only'],17)
        cb.pack(side='left',padx=(0,6))
        cb.bind('<<ComboboxSelected>>',lambda e:self.draw_dashboard_bosses())
        self.ov_boss_search=tk.StringVar(value='')
        self.ov_boss_search.trace_add('write',lambda *_:self.draw_dashboard_bosses() if self.page=='Overview' else None)
        self.entry(filt,self.ov_boss_search).pack(side='left',fill='x',expand=True,ipady=4)
        bossbox=self.panel(right)
        bossbox.pack(fill='x',expand=False)
        bossbox.pack_propagate(False)
        # Leave usable space for boss detail/actions at low window heights.
        right.bind('<Configure>',lambda e:bossbox.configure(height=max(185,min(430,e.height-282))))
        self.ov_boss_tree=self.row_tree(bossbox,[('fav','★',34),('name','BOSS',155),('region','REGION',84),('timer','NEXT SPAWN*',105)],8)
        self.ov_boss_tree.bind('<<TreeviewSelect>>',lambda e:self.dashboard_boss_selection())
        self.ov_boss_tree.bind('<Double-1>',lambda e:self.toggle_favorite())
        self.ov_boss_rows={}
        detail=self.panel(right,CARD)
        detail.pack(fill='x',pady=(11,0))
        self.label(detail,'✦  SELECTED BOSS',10,GOLD,True).pack(anchor='w',padx=13,pady=(10,6))
        self.ov_detail_name=self.label(detail,'Choose a boss',13,TEXT,True)
        self.ov_detail_name.pack(anchor='w',padx=13)
        self.ov_detail_location=self.label(detail,'Location and status',9,MUTED,wraplength=420,justify='left')
        self.ov_detail_location.pack(anchor='w',padx=13,pady=4)
        self.ov_detail_timer=self.label(detail,'No timer recorded',17,BLUE,True)
        self.ov_detail_timer.pack(anchor='w',padx=13,pady=4)
        buttons=tk.Frame(detail,bg=CARD);buttons.pack(fill='x',padx=9,pady=(0,7))
        self.button(buttons,'★ Favorite',self.toggle_favorite,compact=True).pack(side='left',padx=3)
        self.button(buttons,'Record kill',self.dashboard_mark_kill,True,compact=True).pack(side='left',padx=3)
        self.button(buttons,'Map ↗',self.open_boss_map,compact=True).pack(side='left',padx=3)
        self.label(right,'* Respawns are manually estimated, not live server data.',8,MUTED).pack(anchor='w',pady=(6,0))
        if self.selected_boss is None:
            self.selected_boss=next((b for b in BOSSES if b.key in self.state['favorites']),BY_KEY.get('Verteron:High Commander Lagta'))
        self.draw_dashboard_bosses()

    def page_map(self):
        self.ornate_heading(self.body,'Elyos world boss maps','External community map links')
        self.label(self.body,'Select a region to open verified community field-boss markers in your browser.',12,TEXT).pack(anchor='w',pady=(0,18))
        for region in ('Verteron','Eltnen'):
            card=self.panel(self.body,CARD);card.pack(fill='x',pady=9)
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',padx=17,pady=15)
            self.label(row,'⌖  '+region+' — Elyos field bosses',15,GOLD,True).pack(side='left')
            self.button(row,'View map ↗',lambda r=region:webbrowser.open(MAP_LINKS[r]),True).pack(side='right')
        self.label(self.body,'The map links open outside Aion2Rader. No positions are read from your game.',10,MUTED).pack(anchor='w',pady=20)

    def draw_dashboard_bosses(self):
        if not hasattr(self,'ov_boss_tree'):return
        fav=set(self.state['favorites']);flt=self.ov_boss_filter.get()
        query=self.ov_boss_search.get().strip().casefold();now=time.time()
        self.ov_boss_rows={}
        for item in self.ov_boss_tree.get_children():self.ov_boss_tree.delete(item)
        for b in sorted(BOSSES,key=lambda b:(b.key not in fav,b.region!='Verteron',b.name)):
            if flt=='★ Favorites only' and b.key not in fav:continue
            if flt=='Verteron only' and b.region!='Verteron':continue
            if flt=='Eltnen only' and b.region!='Eltnen':continue
            if query not in (b.name+' '+b.region+' '+b.location).casefold():continue
            ts=self.boss_deadline(b)
            row=self.ov_boss_tree.insert('',tk.END,values=('★' if b.key in fav else '☆',b.name,b.region,clock(ts-now) if ts else 'Not recorded'),tags=('near' if b.key in fav else '',))
            self.ov_boss_rows[row]=b
            if self.selected_boss and b.key==self.selected_boss.key:self.ov_boss_tree.selection_set(row)
        self.draw_dashboard_detail()

    def dashboard_boss_selection(self):
        sel=self.ov_boss_tree.selection()
        if not sel:return
        self.selected_boss=self.ov_boss_rows.get(sel[0])
        if self.selected_boss:
            self.var_boss_minutes.set(str(self.selected_boss.minutes or ''))
            self.draw_dashboard_detail()

    def draw_dashboard_detail(self):
        if self.page!='Overview' or not hasattr(self,'ov_detail_name'):return
        b=self.selected_boss
        if not b:return
        self.ov_detail_name.configure(text=('★  ' if b.key in self.state['favorites'] else '☆  ')+b.name)
        self.ov_detail_location.configure(text=f'{b.region} (Elyos)  ·  {b.location}  ·  Level {b.level}')
        ts=self.boss_deadline(b)
        self.ov_detail_timer.configure(text=clock(ts-time.time()) if ts else 'No timer recorded')

    def dashboard_mark_kill(self):
        b=self.selected_boss
        if not b:return
        if b.minutes is None:
            entered=simpledialog.askinteger('Estimated respawn',f'Enter respawn minutes for {b.name}.',minvalue=1,maxvalue=2880,parent=self)
            if entered is None:return
            self.var_boss_minutes.set(str(entered))
        else:self.var_boss_minutes.set(str(b.minutes))
        self.mark_kill()

    def show_page(self,page):
        self.page=page
        for n,b in self.nav_buttons.items():b.configure(bg=CARD2 if n==page else '#0A1C31',fg=GOLD if n==page else TEXT)
        for w in self.body.winfo_children():w.destroy()
        getattr(self,'page_'+page.lower().replace(' ', '_'))()
        self.refresh_page()

    def row_tree(self,parent,columns,heights=10):
        hold=self.panel(parent)
        hold.pack(fill='both',expand=True,pady=(0,7))
        tree=ttk.Treeview(hold,columns=tuple(k for k,_,_ in columns),show='headings',style='R.Treeview',height=heights,selectmode='browse')
        for key,name,width in columns:
            tree.heading(key,text=name);tree.column(key,width=width,minwidth=32 if key=='fav' else 55,anchor='w',stretch=key==('name' if columns[0][0]=='fav' else columns[0][0]))
        sb=ttk.Scrollbar(hold,orient='vertical',command=tree.yview,style='R.Vertical.TScrollbar')
        tree.configure(yscrollcommand=sb.set);sb.pack(side='right',fill='y');tree.pack(fill='both',expand=True)
        tree.tag_configure('live',foreground=GREEN);tree.tag_configure('near',foreground=GOLD)
        tree.tag_configure('muted',foreground='#758495')
        return tree

    def next_event(self,now):
        return next((e for e in self.events if e['when']>now and e['id'] not in self.state['muted']),None)
    def active_event(self,now):
        return next((e for e in self.events if e['when']<=now<e['when']+e['duration'] and e['duration']>0),None)
    def next_favorite(self,now):
        ks=self._active_kills(now)
        ks=[(t,b) for t,b in ks if b.key in self.state['favorites']]
        return min(ks,key=lambda x:x[0],default=None)

    def page_events(self):
        self.ornate_heading(self.body,'Event schedule','All Global scheduled activities, with editable time corrections.')
        filters=tk.Frame(self.body,bg=BG);filters.pack(fill='x',pady=(0,12))
        c=self.combo(filters,self.var_event_filter,['All events','Festival','Invasion','Rift','Bosses','Sieges','PvP','Resets','Deadline','Field Boss','Personal'],17)
        c.pack(side='left',padx=(0,7));c.bind('<<ComboboxSelected>>',lambda e:self.refresh_page())
        c=self.combo(filters,self.var_period,['Next 12 hours','Next 24 hours','Next 7 days'],16)
        c.pack(side='left',padx=(0,7));c.bind('<<ComboboxSelected>>',lambda e:self.refresh_page())
        self.entry(filters,self.var_event_search).pack(side='left',fill='x',expand=True,ipady=6)
        self.var_event_search.trace_add('write',lambda *a:self.refresh_page() if self.page=='Events' else None)
        self.event_tree=self.row_tree(self.body,[('name','EVENT',275),('kind','CATEGORY',115),('time','LOCAL TIME',174),('left','COUNTDOWN',135)],12)
        self.event_tree.bind('<<TreeviewSelect>>',lambda e:self.show_event_detail())
        actions=tk.Frame(self.body,bg=BG);actions.pack(fill='x',pady=(6,5))
        self.button(actions,'Mute / unmute selected',self.mute_event).pack(side='left',padx=(0,7))
        self.button(actions,'Adjust selected event time',self.shift_event).pack(side='left',padx=(0,7))
        self.button(actions,'Delete personal event',self.delete_personal_event).pack(side='left')
        self.event_detail=self.label(self.body,'Select an event for details.',9,MUTED,wraplength=880,justify='left')
        self.event_detail.pack(anchor='w',pady=(9,0))
        self._event_row={}

    def page_world_bosses(self):
        self.ornate_heading(self.body,'World Bosses · Elyos Only','36 Elyos field bosses across Verteron and Eltnen. Click ★ to favorite; record a kill to start a timer.')
        filt=tk.Frame(self.body,bg=BG);filt.pack(fill='x',pady=(0,12))
        c=self.combo(filt,self.var_boss_filter,['All Elyos bosses','★ Favorites only','Verteron only','Eltnen only'],17)
        c.pack(side='left',padx=(0,8));c.bind('<<ComboboxSelected>>',lambda e:self.refresh_page())
        self.entry(filt,self.var_boss_search).pack(side='left',fill='x',expand=True,ipady=6)
        self.var_boss_search.trace_add('write',lambda *a:self.refresh_page() if self.page=='World Bosses' else None)
        top=tk.Frame(self.body,bg=BG);top.pack(fill='both',expand=True)
        listing=tk.Frame(top,bg=BG);listing.pack(side='left',fill='both',expand=True,padx=(0,10))
        self.boss_tree=self.row_tree(listing,[('fav','★',35),('name','BOSS',220),('region','REGION',76),('timer','NEXT SPAWN*',130)],14)
        self.boss_tree.bind('<<TreeviewSelect>>',lambda e:self.boss_selection())
        self.boss_tree.bind('<Double-1>',lambda e:self.toggle_favorite())
        details=self.panel(top,CARD,width=272);details.pack(side='right',fill='y');details.pack_propagate(False)
        self.label(details,'✦  BOSS DETAILS',12,GOLD,True).pack(anchor='w',padx=15,pady=(12,9))
        art=self.art('hero_boss.png')
        if art:
            boss_art=tk.Canvas(details,height=93,bg=CARD,highlightthickness=0)
            boss_art.pack(fill='x',padx=10,pady=(0,9))
            boss_art.create_image(0,-70,anchor='nw',image=art)

        self.boss_name=self.label(details,'Select a boss',15,TEXT,True,wraplength=235,justify='left')
        self.boss_name.pack(anchor='w',padx=15,pady=(0,5))
        self.boss_area=self.label(details,'',10,MUTED,wraplength=235,justify='left')
        self.boss_area.pack(anchor='w',padx=15)
        self.boss_countdown=self.label(details,'—',23,BLUE,True)
        self.boss_countdown.pack(anchor='w',padx=15,pady=(7,1))
        self.label(details,'Respawn minutes (editable):',9,MUTED).pack(anchor='w',padx=15,pady=(9,4))
        self.entry(details,self.var_boss_minutes,12).pack(anchor='w',padx=15,ipady=5)
        self.button(details,'★ Favorite / unfavorite',self.toggle_favorite,compact=True).pack(fill='x',padx=15,pady=(9,3))
        self.button(details,'Record kill NOW',self.mark_kill,True,compact=True).pack(fill='x',padx=15,pady=3)
        self.button(details,'Clear spawn estimate',self.clear_boss_timer,compact=True).pack(fill='x',padx=15,pady=3)
        self.button(details,'View boss region map ↗',self.open_boss_map,compact=True).pack(fill='x',padx=15,pady=3)
        self.label(details,'* Timers are estimates after a manually recorded kill, never live game data.',8,MUTED,wraplength=226,justify='left').pack(anchor='w',padx=15,pady=(5,0))
        self._boss_row={}

    def page_calendar(self):
        self.ornate_heading(self.body,'Weekly Calendar','Seven days of upcoming events, scheduled in your computer time.')
        self.button(self.body,'Export next 7 days (.ics)',self.export_ics,True).pack(anchor='w',pady=(0,12))
        self.calendar_tree=self.row_tree(self.body,[('day','DAY',130),('event','EVENT',270),('time','START',155),('status','CONFIDENCE',150)],13)
        self.label(self.body,'Calendar events are calculated. Please verify changing schedules in game.',9,MUTED).pack(anchor='w',pady=(4,0))
        add=self.panel(self.body,CARD);add.pack(fill='x',pady=(9,0))
        self.label(add,'ADD SPECIAL / PERSONAL EVENT',10,GOLD,True).pack(anchor='w',padx=12,pady=(8,5))
        inputs=tk.Frame(add,bg=CARD);inputs.pack(fill='x',padx=12,pady=(0,9))
        self.custom_name=tk.StringVar()
        self.custom_when=tk.StringVar(value=(datetime.now()+timedelta(hours=1)).strftime('%Y-%m-%d %H:%M'))
        en=self.entry(inputs,self.custom_name,26);en.pack(side='left',padx=(0,8),ipady=6)
        dt=self.entry(inputs,self.custom_when,19);dt.pack(side='left',padx=(0,8),ipady=6)
        self.button(inputs,'Add event',self.add_custom_event,True,compact=True).pack(side='left')
        self.label(add,'Event name                         YYYY-MM-DD HH:MM (local time)',8,MUTED).pack(anchor='w',padx=12,pady=(0,8))

    def page_settings(self):
        self.ornate_heading(self.body,'Preferences','Customize your alerts, server schedule and floating mini timer.')
        box=self.panel(self.body,CARD);box.pack(fill='x',pady=(0,12))
        self.label(box,'SERVER REGION',10,GOLD,True).pack(anchor='w',padx=18,pady=(14,6))
        c=self.combo(box,self.var_region,list(REGIONS),24);c.pack(anchor='w',padx=18,pady=(0,14))
        c.bind('<<ComboboxSelected>>',lambda e:(self.save(),self.recalculate()))
        opts=self.panel(self.body,CARD);opts.pack(fill='x',pady=(0,12))
        self.label(opts,'NOTIFICATIONS',10,GOLD,True).pack(anchor='w',padx=18,pady=(15,8))
        for label,var,action in [
          ('Enable event reminders',self.var_alert,self.save),
          ('Popup when an event goes LIVE',self.var_live,self.save),
          ('Play alert sound',self.var_sound,self.save),
          ('Alert for favorite world-boss estimates',self.var_fav_alert,self.save),
          ('Keep main window always on top',self.var_top,self.toggle_top)]:
            self.check(opts,label,var,action).pack(anchor='w',padx=16,pady=1)
        lr=tk.Frame(opts,bg=CARD);lr.pack(anchor='w',padx=19,pady=(10,15))
        self.label(lr,'Remind before:',10,TEXT).pack(side='left',padx=(0,9))
        c=self.combo(lr,self.var_lead,['1','3','5','10','15','30'],5);c.pack(side='left')
        c.bind('<<ComboboxSelected>>',lambda e:self.save())
        self.label(lr,'minutes',10,MUTED).pack(side='left',padx=9)
        actions=tk.Frame(self.body,bg=BG);actions.pack(fill='x',pady=(1,13))
        self.button(actions,'Test LIVE popup',lambda:self.notify('LIVE NOW • DEMO','Shugo Festival • Example notification',True),True).pack(side='left',padx=(0,8))
        self.button(actions,'Test boss popup',lambda:self.notify('★ FAVORITE BOSS','Lagta is expected soon (example).')).pack(side='left',padx=(0,8))
        self.button(actions,'Toggle floating overlay',self.toggle_mini).pack(side='left')
        self.label(self.body,'Saved in AppData\\Aion2Rader. Existing V1.1 settings are migrated automatically on first launch.',9,MUTED).pack(anchor='w')

    def page_updates(self):
        self.ornate_heading(self.body,'Software Updates','Version history, release notes and opt-in in-app updates.')
        box=self.panel(self.body,CARD);box.pack(fill='x',pady=(0,14))
        self.label(box,'✦  CURRENT VERSION',10,GOLD,True).pack(anchor='w',padx=18,pady=(18,6))
        self.label(box,'Aion2Rader — Update V2.1',19,TEXT,True).pack(anchor='w',padx=18)
        self.label(box,'Build • 18 October 2026',10,MUTED).pack(anchor='w',padx=18,pady=(0,17))
        source=self.panel(self.body,CARD);source.pack(fill='x',pady=(0,14))
        self.label(source,'SECURE UPDATE SOURCE (HTTPS)',10,GOLD,True).pack(anchor='w',padx=18,pady=(16,7))
        self.label(source,'Paste the release manifest URL once updates are hosted (e.g. on GitHub).',9,MUTED).pack(anchor='w',padx=18,pady=(0,7))
        self.entry(source,self.var_update_url).pack(fill='x',padx=18,ipady=7)
        bar=tk.Frame(source,bg=CARD);bar.pack(fill='x',padx=18,pady=(12,11))
        self.button(bar,'Check for updates',self.check_updates,True).pack(side='left',padx=(0,8))
        self.install_btn=self.button(bar,'Download & install',self.install_online)
        self.install_btn.pack(side='left');self.install_btn.configure(state='disabled')
        self.button(bar,'Install local update ZIP…',self.install_local).pack(side='right')
        self.update_status=self.label(source,'',9,MUTED,wraplength=700,justify='left')
        self.update_status.pack(anchor='w',padx=18,pady=(0,15))
        history=self.panel(self.body);history.pack(fill='both',expand=True)
        self.label(history,'PATCH NOTES & VERSION HISTORY',11,GOLD,True).pack(anchor='w',padx=17,pady=(14,9))
        notes=[('UPDATE V2.1','Per-second countdowns on all pages, illustrated fantasy dashboard with event cards, Elyos boss tracker on Overview, polished top navigation and art. Maintains V2 favorites and settings.'),
               ('UPDATE V2.0','Fantasy blue-and-gold interface, Elyos-only world bosses (Verteron + Eltnen), stars/favorites, boss kill timers, boss alerts, and Updates tab.'),
               ('UPDATE V1.1','LIVE NOW event popup with sound, reminder controls and mini overlay.'),
               ('UPDATE V1.0','Initial Global events, recurring countdowns, regions and .ics export.')]
        for ver,desc in notes:
            block=tk.Frame(history,bg=PANEL);block.pack(fill='x',padx=17,pady=(0,10))
            self.label(block,ver,10,BLUE,True).pack(anchor='w')
            self.label(block,desc,9,TEXT,wraplength=730,justify='left').pack(anchor='w',pady=(3,0))
        self.label(history,'Updates require an online release manifest. No update server is included in V2.0.',9,MUTED).pack(anchor='w',padx=17,pady=3)
        self.refresh_update_status()

    def recalculate(self):
        self.events=occurrences(self.var_region.get(),time.time(),8,self.state.get('shifts',{}),
                                self.state.get('extras',[]),self.state.get('kills',[]))
        self.last_calc=time.time();self.refresh_page()
    def _active_kills(self,now=None):
        now=time.time() if now is None else now
        latest={}
        for k in self.state.get('kills',[]):
            key=k.get('boss_key')
            b=BY_KEY.get(key)
            if not b:continue
            try:
                ts=float(k['kill'])+float(k['minutes'])*60
                if ts>now and (key not in latest or ts>latest[key][0]):latest[key]=(ts,b)
            except (ValueError,TypeError,KeyError):continue
        return list(latest.values())
    def boss_deadline(self,b):
        entries=[ts for ts,boss in self._active_kills() if boss.key==b.key]
        return max(entries) if entries else None
    def refresh_page(self):
        if self.page=='Overview' and hasattr(self,'ov_tree'):self.draw_overview()
        elif self.page=='Events' and hasattr(self,'event_tree'):self.draw_events()
        elif self.page=='World Bosses' and hasattr(self,'boss_tree'):self.draw_bosses()
        elif self.page=='Calendar' and hasattr(self,'calendar_tree'):self.draw_calendar()
    def draw_overview(self):
        now=time.time()
        for item in self.ov_tree.get_children():self.ov_tree.delete(item)
        self._overview_rows={}
        ct=0
        for e in self.events:
            if e['when']+e['duration']<now or e['id'] in self.state['muted']:continue
            if ct>=18:break
            secs=e['when']-now
            row=self.ov_tree.insert('',tk.END,values=(e['name'],datetime.fromtimestamp(e['when']).strftime('%H:%M'),
                'LIVE NOW' if secs<=0 else clock(secs)),tags=('live' if secs<=0 else 'near' if secs<600 else '',))
            self._overview_rows[row]=e;ct+=1
        self.draw_dashboard_bosses()
        self.update_visible_countdowns(now)

    def update_visible_countdowns(self,now):
        """Only modify countdown cells. Never rebuild entire lists each second."""
        if self.page=='Overview' and hasattr(self,'ov_tree'):
            nearest=self.next_event(now)
            active=self.active_event(now)
            featured=active or nearest
            self.ov_ec.itemconfigure(self.ov_event_id,text=featured['name'] if featured else 'No event scheduled')
            self.ov_ec.itemconfigure(self.ov_timer_id,text=('LIVE NOW' if active else clock(nearest['when']-now) if nearest else '—'),fill=GREEN if active else BLUE)
            self.ov_ec.itemconfigure(self.ov_event_desc_id,text=(display_time(featured['when']) if featured else 'Check Events page'))
            fav=self.next_favorite(now)
            self.ov_bc.itemconfigure(self.ov_boss_id,text=fav[1].name if fav else 'Favorite a boss')
            self.ov_bc.itemconfigure(self.ov_boss_time_id,text=clock(fav[0]-now) if fav else 'No estimate yet')
            self.ov_bc.itemconfigure(self.ov_boss_desc_id,text=fav[1].location if fav else 'Record a boss kill to start its timer')
            for row,e in self._overview_rows.items():
                if self.ov_tree.exists(row):
                    secs=e['when']-now
                    self.ov_tree.set(row,'in','LIVE NOW' if secs<=0<secs+e['duration'] else clock(secs) if secs>0 else 'ENDED')
                    self.ov_tree.item(row,tags=('live' if secs<=0<secs+e['duration'] else 'near' if 0<secs<600 else '',))
            live=[e for e in self.events if e['duration']>0 and e['when']<=now<e['when']+e['duration'] and e['id'] not in self.state['muted']]
            for i,(nm,tm) in enumerate(self.live_tiles):
                if i<len(live):
                    nm.configure(text=live[i]['name'],fg=TEXT)
                    tm.configure(text='●  LIVE NOW  ·  '+clock(live[i]['when']+live[i]['duration']-now),fg=GREEN)
                else:
                    nxt=[e for e in self.events if e['when']>now and e['id'] not in self.state['muted']]
                    item=nxt[i-len(live)] if i-len(live)<len(nxt) else None
                    nm.configure(text=item['name'] if item else 'No upcoming event',fg=TEXT)
                    tm.configure(text=clock(item['when']-now) if item else '—',fg=GOLD)
            nxt=[e for e in self.events if e['when']>now and e['id'] not in self.state['muted']][:3]
            self.ov_next_text.configure(text='\n'.join(f"✧  {e['name']}: {clock(e['when']-now)}" for e in nxt))
            for row,b in getattr(self,'ov_boss_rows',{}).items():
                if self.ov_boss_tree.exists(row):
                    ts=self.boss_deadline(b)
                    self.ov_boss_tree.set(row,'timer',clock(ts-now) if ts else 'Not recorded')
            self.draw_dashboard_detail()
        elif self.page=='Events' and hasattr(self,'event_tree'):
            for row,e in self._event_row.items():
                if self.event_tree.exists(row):
                    secs=e['when']-now
                    self.event_tree.set(row,'left','LIVE NOW' if secs<=0<secs+e['duration'] else clock(secs) if secs>0 else 'ENDED')
                    self.event_tree.item(row,tags=('muted' if e['id'] in self.state['muted'] else 'live' if secs<=0<secs+e['duration'] else 'near' if 0<secs<600 else '',))
        elif self.page=='World Bosses' and hasattr(self,'boss_tree'):
            for row,b in self._boss_row.items():
                if self.boss_tree.exists(row):
                    ts=self.boss_deadline(b)
                    self.boss_tree.set(row,'timer',clock(ts-now) if ts else 'Not recorded')
            if self.selected_boss:self.draw_boss_detail()

    def draw_events(self):
        self._event_row={}
        for i in self.event_tree.get_children():self.event_tree.delete(i)
        now=time.time();window={'Next 12 hours':12*3600,'Next 24 hours':86400,'Next 7 days':7*86400}[self.var_period.get()]
        for e in self.events:
            secs=e['when']-now
            if secs < -e['duration'] or secs>window:continue
            if self.var_event_filter.get()!='All events' and self.var_event_filter.get()!=e['category']:continue
            if self.var_event_search.get().casefold().strip() not in e['name'].casefold():continue
            if len(self._event_row)>=450:break
            name=('◌  ' if e['id'] in self.state['muted'] else '')+e['name']
            row=self.event_tree.insert('',tk.END,values=(name,e['category'],display_time(e['when']),
                 'LIVE NOW' if secs<=0 else clock(secs)),tags=('muted' if e['id'] in self.state['muted'] else 'live' if secs<=0 else 'near' if secs<600 else '',))
            self._event_row[row]=e
    def selected_event(self):
        sel=self.event_tree.selection() if hasattr(self,'event_tree') else ()
        return self._event_row.get(sel[0]) if sel else None
    def show_event_detail(self):
        e=self.selected_event()
        if e:self.event_detail.configure(text=f"{e['name']}  •  {e['reliability']}  •  {e['detail']}")
    def mute_event(self):
        e=self.selected_event()
        if not e:return
        muted=set(self.state['muted']);muted.symmetric_difference_update({e['id']});self.state['muted']=sorted(muted)
        self.save();self.draw_events()
    def delete_personal_event(self):
        e=self.selected_event()
        if not e or not e['id'].startswith('user:'):
            messagebox.showinfo('Delete event','Select a personal event from the Events page.',parent=self);return
        code=e['id'].split(':',1)[1]
        self.state['extras']=[x for x in self.state['extras'] if str(x.get('id'))!=code]
        self.save();self.recalculate()
    def shift_event(self):
        e=self.selected_event()
        if not e:return
        if e['id'] not in [d.code for d in DEFS]:
            messagebox.showinfo('Time correction','Only repeating events can be shifted.',parent=self);return
        delta=simpledialog.askinteger('Time correction',f"Shift {e['name']} from its default schedule, in minutes\n(e.g. -60 or +60)",initialvalue=int(self.state['shifts'].get(e['id'],0)),minvalue=-720,maxvalue=720,parent=self)
        if delta is not None:self.state['shifts'][e['id']]=delta;self.save();self.recalculate()
    def draw_bosses(self):
        self._boss_row={}
        for item in self.boss_tree.get_children():self.boss_tree.delete(item)
        fav=set(self.state['favorites']);flt=self.var_boss_filter.get()
        search=self.var_boss_search.get().strip().casefold();now=time.time()
        selected=self.selected_boss.key if self.selected_boss else None
        for b in sorted(BOSSES,key=lambda b:(b.key not in fav,b.region!='Verteron',b.name)):
            if flt=='★ Favorites only' and b.key not in fav:continue
            if flt=='Verteron only' and b.region!='Verteron':continue
            if flt=='Eltnen only' and b.region!='Eltnen':continue
            if search not in (b.name+' '+b.region+' '+b.location).casefold():continue
            ts=self.boss_deadline(b)
            row=self.boss_tree.insert('',tk.END,values=('★' if b.key in fav else '☆',b.name,b.region,clock(ts-now) if ts else 'Not recorded'),tags=('near' if b.key in fav else '',))
            self._boss_row[row]=b
            if b.key==selected:self.boss_tree.selection_set(row)
        if self.selected_boss:self.draw_boss_detail()
    def boss_selection(self):
        s=self.boss_tree.selection()
        if not s:return
        b=self._boss_row.get(s[0]);self.selected_boss=b
        self.var_boss_minutes.set(str(b.minutes) if b and b.minutes is not None else '')
        self.draw_boss_detail()
    def draw_boss_detail(self):
        b=self.selected_boss
        if b is None:return
        self.boss_name.configure(text=('★ ' if b.key in self.state['favorites'] else '☆ ')+b.name)
        self.boss_area.configure(text=f'{b.region} (Elyos)\n{b.location}\nLevel {b.level}\n'+
             (f'Community respawn estimate: {b.minutes} min' if b.minutes else 'Respawn interval not confirmed; enter a value.'))
        ts=self.boss_deadline(b)
        self.boss_countdown.configure(text=clock(ts-time.time()) if ts else 'No timer')
    def toggle_favorite(self):
        b=self.selected_boss
        if b is None:return
        fav=set(self.state['favorites']);fav.symmetric_difference_update({b.key})
        self.state['favorites']=sorted(fav);self.save();self.draw_bosses() if self.page=='World Bosses' else self.draw_dashboard_bosses()
    def mark_kill(self):
        b=self.selected_boss
        if not b:return
        try:
            mins=int(self.var_boss_minutes.get())
            if not (1<=mins<=2880):raise ValueError()
        except ValueError:
            messagebox.showwarning('Respawn needed','Enter an estimated respawn from 1 to 2880 minutes.\nFor Eltnen, no default interval is confirmed.',parent=self);return
        self.state['kills']=[k for k in self.state['kills'] if k.get('boss_key')!=b.key]
        self.state['kills'].append({'id':str(uuid.uuid4()),'boss_key':b.key,'name':b.name,
            'kill':int(time.time()),'minutes':mins})
        self.save();self.recalculate()
    def clear_boss_timer(self):
        if not self.selected_boss:return
        key=self.selected_boss.key
        self.state['kills']=[k for k in self.state['kills'] if k.get('boss_key')!=key]
        self.save();self.recalculate()
    def open_boss_map(self):
        if self.selected_boss:webbrowser.open(MAP_LINKS[self.selected_boss.region])
    def draw_calendar(self):
        for i in self.calendar_tree.get_children():self.calendar_tree.delete(i)
        now=time.time()
        for e in self.events:
            if not now<e['when']<now+7*86400:continue
            self.calendar_tree.insert('',tk.END,values=(datetime.fromtimestamp(e['when']).strftime('%a %d %b'),
               e['name'],datetime.fromtimestamp(e['when']).strftime('%H:%M'),e['reliability']))
    def add_custom_event(self):
        name=self.custom_name.get().strip()
        if not 1<=len(name)<=100:
            messagebox.showwarning('Event name','Please enter an event name (1–100 characters).',parent=self);return
        try:
            when=datetime.strptime(self.custom_when.get().strip(),'%Y-%m-%d %H:%M').timestamp()
            if when<time.time()-60:raise ValueError('Past date')
        except ValueError:
            messagebox.showwarning('Invalid date','Use YYYY-MM-DD HH:MM, for example 2026-10-19 17:00.',parent=self);return
        self.state['extras'].append({'id':str(uuid.uuid4()),'name':name,'when':int(when)})
        self.custom_name.set('');self.save();self.recalculate()

    def export_ics(self):
        now=time.time()
        future=[e for e in self.events if now<e['when']<now+7*86400 and e['id'] not in self.state['muted']]
        filename=filedialog.asksaveasfilename(defaultextension='.ics',initialfile='Aion2Rader_7_day_calendar.ics',filetypes=[('iCalendar','*.ics')],parent=self)
        if not filename:return
        Path(filename).write_text(ics(future,int(self.var_lead.get())),encoding='utf-8')
        messagebox.showinfo('Calendar exported',f'{len(future)} events exported.',parent=self)
    def toggle_top(self):
        self.attributes('-topmost',self.var_top.get());self.save()
    def toggle_mini(self):
        if self.mini is not None:
            try:self.mini.destroy()
            except tk.TclError:pass
            self.mini=None;return
        m=tk.Toplevel(self)
        m.title('Aion2Rader · Floating Events')
        m.configure(bg=BG);m.geometry('340x250+120+130');m.minsize(295,230)
        m.attributes('-topmost',True)
        try:m.attributes('-alpha',0.94)
        except tk.TclError:pass
        self.mini=m
        shell=self.panel(m,CARD)
        shell.pack(fill='both',expand=True,padx=4,pady=4)
        header=tk.Frame(shell,bg='#0A1C31');header.pack(fill='x')
        self.label(header,'✦  AION2RADER  ·  EVENTS',10,GOLD,True,bg='#0A1C31').pack(side='left',padx=12,pady=8)
        self.button(header,'✕',self.toggle_mini,compact=True).pack(side='right',padx=5)
        self.mini_rows=[]
        for i in range(4):
            row=tk.Frame(shell,bg=CARD if i%2==0 else PANEL)
            row.pack(fill='x',padx=8,pady=3)
            nm=self.label(row,'Event loading…',10,TEXT,True)
            nm.pack(side='left',fill='x',expand=True,padx=(7,3),pady=5)
            tm=self.label(row,'—',10,BLUE,True)
            tm.pack(side='right',padx=(0,8))
            self.mini_rows.append((nm,tm))
        self.label(shell,'Estimated times • Verify in-game',8,MUTED).pack(anchor='w',padx=12,pady=(6,0))
        m.protocol('WM_DELETE_WINDOW',self.toggle_mini)
        self.refresh_mini(time.time())

    def refresh_mini(self,now):
        if self.mini is None:return
        current=[e for e in self.events if e['duration']>0 and e['when']<=now<e['when']+e['duration'] and e['id'] not in self.state['muted']]
        upcoming=[e for e in self.events if e['when']>now and e['id'] not in self.state['muted']]
        picks=(current+upcoming)[:4]
        for i,(nm,tm) in enumerate(self.mini_rows):
            if i>=len(picks):nm.configure(text='—');tm.configure(text='');continue
            e=picks[i];is_live=e['when']<=now
            nm.configure(text=e['name'][:25])
            tm.configure(text='LIVE NOW' if is_live else clock(e['when']-now),fg=GREEN if is_live else BLUE)

    def notify(self,title,body,live=False):
        if self.var_sound.get():
            if sys.platform=='win32':
                try:
                    import winsound
                    winsound.PlaySound('SystemExclamation',winsound.SND_ALIAS|winsound.SND_ASYNC)
                except Exception:self.bell()
            else:self.bell()
        if self.toast is not None:
            try:self.toast.destroy()
            except tk.TclError:pass
        t=tk.Toplevel(self);self.toast=t;t.title('Aion2Rader | Notification')
        t.configure(bg=CARD);t.attributes('-topmost',True)
        shell=self.panel(t,CARD);shell.pack(fill='both',expand=True,padx=6,pady=6)
        self.label(shell,'✦  A I O N 2 R A D E R   •   UPDATE V2.1',9,GOLD,True).pack(anchor='w',padx=18,pady=(12,3))
        content=tk.Frame(shell,bg=CARD);content.pack(fill='x',padx=14,pady=4)
        icon=self.art('icon_Bosses.png' if 'BOSS' in title else 'icon_Festival.png')
        if icon:tk.Label(content,image=icon,bg=CARD).pack(side='left',padx=(0,13))
        self.label(content,title,17,GREEN if live else GOLD,True,wraplength=325,justify='left').pack(side='left',fill='x',expand=True)
        self.label(shell,body,11,TEXT,wraplength=385,justify='left').pack(anchor='w',padx=18,pady=(0,10))
        self.button(shell,'Dismiss',t.destroy).pack(anchor='e',padx=16,pady=(0,12))
        t.update_idletasks();w=max(420,t.winfo_reqwidth());h=t.winfo_reqheight()
        t.geometry(f'{w}x{h}+{max(0,t.winfo_screenwidth()-w-28)}+{max(0,t.winfo_screenheight()-h-100)}')
        t.lift();t.after(60000 if live else 20000,lambda:t.destroy() if t.winfo_exists() else None)
    def alerts_check(self):
        now=time.time();prev=self.last_alert_poll;self.last_alert_poll=now
        if not self.var_alert.get():return
        if self.var_live.get():
            started=events_just_started(self.events,prev,now,self.state['muted'],self.seen)
            if started:
                for e in started:self.seen.add(('live',e['id'],e['when']))
                self.notify('LIVE NOW  •  EVENT STARTED','\n'.join('• '+e['name'] for e in started[:5]),True)
                return
        lead=int(self.var_lead.get())*60
        # Start-crossing check instead of repeated notification each second.
        group=[]
        for e in self.events:
            at=e['when']-lead
            key=('early',e['id'],e['when'],lead)
            if prev<at<=now and e['id'] not in self.state['muted'] and key not in self.seen:
                self.seen.add(key);group.append(e)
        if group:self.notify('EVENTS STARTING SOON','\n'.join('• '+e['name'] for e in group[:5]))
        if self.var_fav_alert.get():
            # Spawn-at-time alert for a favorite boss: no live-server confirmation.
            starts=[]
            for k in self.state.get('kills',[]):
                b=BY_KEY.get(k.get('boss_key'))
                if not b or b.key not in self.state['favorites']:continue
                try:ts=float(k['kill'])+float(k['minutes'])*60
                except (KeyError,TypeError,ValueError):continue
                key=('boss-live',b.key,ts)
                if prev<ts<=now and key not in self.seen:
                    self.seen.add(key);starts.append(b)
            if starts:
                self.notify('★ FAVORITE BOSS EXPECTED NOW','\n'.join(f'• {b.name}  ({b.region})' for b in starts[:5]),True)
                return
            for ts,b in self._active_kills(now):
                k=('boss',b.key,ts,lead)
                if b.key in self.state['favorites'] and prev<ts-lead<=now and k not in self.seen:
                    self.seen.add(k);self.notify('★ FAVORITE BOSS SPAWN SOON',f'{b.name}\n{b.region} · {b.location}\nEstimated in {clock(ts-now)}')
        if len(self.seen)>3000:self.seen.clear()
    def tick(self):
        try:
            now=time.time();second=int(now)
            if second!=self.last_clock_second:
                self.last_clock_second=second
                self.now_label.configure(text='LOCAL TIME  ·  '+datetime.now().strftime('%a %d %b   %H:%M:%S'))
                if now-self.last_calc>60:self.recalculate()
                elif now-self.last_redraw>25:
                    self.refresh_page();self.last_redraw=now
                self.update_visible_countdowns(now)
                if self.mini is not None:
                    try:self.refresh_mini(now)
                    except tk.TclError:self.mini=None
                self.alerts_check()
        except Exception as exc:
            try:self.status.configure(text=f'Error: {exc}')
            except tk.TclError:pass
        finally:
            # Align to the next wall-clock second: smooth 1-second transitions,
            # independent of slow schedule/database redraws.
            delay=max(65,min(1000,int((1-(time.time()%1))*1000)+25))
            self.after(delay,self.tick)


    def refresh_update_status(self):
        if hasattr(self,'update_status'):self.update_status.configure(text=self.var_update_status.get())
    def check_updates(self):
        url=self.var_update_url.get().strip();self.save()
        if not url:
            self.var_update_status.set('No source yet. Add a publisher-hosted HTTPS manifest URL to enable remote updates.')
            self.refresh_update_status();return
        self.var_update_status.set('Checking update server…');self.refresh_update_status()
        def worker():
            try:
                manifest=check_manifest(url,VERSION)
                self.after(0,lambda:self.update_check_complete(manifest))
            except Exception as exc:self.after(0,lambda e=str(exc):self.update_failed(e))
        threading.Thread(target=worker,daemon=True).start()
    def update_check_complete(self,manifest):
        self.pending_update=manifest if manifest['newer'] else None
        if self.pending_update:
            self.var_update_status.set(f"Update V{manifest['version']} available.\n{manifest['notes']}")
            self.install_btn.configure(state='normal')
        else:
            self.var_update_status.set(f"Already current (remote version: {manifest['version']}).")
            self.install_btn.configure(state='disabled')
        self.refresh_update_status()
    def update_failed(self,error):
        self.var_update_status.set('Update check failed: '+error);self.refresh_update_status()
        if hasattr(self,'install_btn'):self.install_btn.configure(state='disabled')
    def install_online(self):
        m=self.pending_update
        if not m:return
        if not messagebox.askyesno('Install update',f"Download and install version {m['version']}?\n\nSHA-256 will be checked before installing.",parent=self):return
        self.var_update_status.set('Downloading and validating package…');self.refresh_update_status()
        def worker():
            try:
                root=self.home/'updates'/('v'+m['version'])
                zipfile=self.home/'updates'/('v'+m['version']+'.zip')
                download_package(m,zipfile)
                result=safe_extract_package(zipfile,root)
                zipfile.unlink(missing_ok=True)
                self.after(0,lambda:self.complete_install(result))
            except Exception as exc:self.after(0,lambda e=str(exc):self.update_failed(e))
        threading.Thread(target=worker,daemon=True).start()
    def install_local(self):
        path=filedialog.askopenfilename(filetypes=[('Update package','*.zip')],parent=self)
        if not path:return
        if not messagebox.askyesno('Trust local update?','Only import ZIP updates from a source you trust. The package will run program code. Continue?',parent=self):return
        # This local option is explicitly user-selected; only remote packages get automatic SHA verification.
        dest=self.home/'updates'/('local-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
        try:ready=safe_extract_package(path,dest)
        except Exception as exc:messagebox.showerror('Could not install',str(exc),parent=self);return
        self.complete_install(ready)
    def complete_install(self,new_root):
        if not messagebox.askyesno('Update staged','Update files are ready. Restart into the new version now?\nYour settings and favorites remain saved.',parent=self):return
        target=Path(new_root)
        exe=target/'Aion2Rader.exe'
        script=target/'tracker.py'
        try:
            if exe.exists():subprocess.Popen([str(exe)],cwd=str(target))
            elif script.exists():
                # Frozen users without Python require an EXE update archive.
                if getattr(sys,'frozen',False):raise RuntimeError('This release contains Python sources only. Install the .exe edition instead.')
                subprocess.Popen([sys.executable,str(script)],cwd=str(target))
            else:raise RuntimeError('No executable found')
        except Exception as exc:
            messagebox.showerror('Could not restart',str(exc),parent=self);return
        self.exit()
    def exit(self):self.save();self.destroy()

if __name__=='__main__':
    App().mainloop()
