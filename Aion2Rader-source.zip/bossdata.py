"""Only Elyos-zone field bosses, cross-checked against MetaBot's Global client tables.
Verteron respawn intervals are community estimates; Eltnen intervals unconfirmed.
"""
from dataclasses import dataclass
@dataclass(frozen=True)
class Boss:
    name: str
    region: str
    location: str
    level: int
    minutes: int | None = None
    @property
    def key(self): return f'{self.region}:{self.name}'

# region, names, locations, levels, community respawn estimates in minutes
_VERTERON = [
 ('Black Tentacle Lawa','Altamia Canyon',45,240),
 ('Centurion Demiros','Destroyed Temple Site',45,240),
 ('Divine Ansas','Contaminated Sanctum',45,360),
 ('Heretic Layla','Rock Tomb Hill',45,180),
 ('Blooming Korin','Ellun River Midstream',45,60),
 ('Kernon of the West','Western Cantas Valley',45,30),
 ('Neikel of the East','Eastern Cantas Valley',45,30),
 ("Sentinel K'nash",'Drana Processing Area',45,240),
 ('Harvest Manager Moshav','Drana Processing Area',45,180),
 ('Rotten Kutar','Ellun River Marsh',45,30),
 ('Researcher Setram','Nahid Brigade Fortress',45,360),
 ('Forest Warrior Aullamu','Aullaeu Village',45,240),
 ('Scholar Aulla','Aullaeu Village',45,120),
 ('Chaser Taulo','Forest of Exiles',45,120),
 ('Phantasm Kasia','Garden of the Illusion God',45,360),
 ('Bloodfang Pnyn','Northern Tolbas Forest',45,180),
 ('Furious Saursus','Night Dew Cave',45,180),
 ('Kusan the Mad Gladiator','Verteron Fortress Ruins',45,120),
 ('Ritualist Garshim','Verteron Fortress Ruins',45,120),
 ('Bodyguard Teegant','Destroyed Abyss Gate',45,90),
 ('Silent Dartan','Southern Altamia Highland',48,360),
 ('Soul Ruler Kashapa','Eastern Altamia Highland',48,360),
 ('High Commander Lagta','Drana Plantation',48,720),
 ('Eternal Gartua','Eternal Isle',51,720),
]
_ELTNEN = [
 ("First Test Subject K'tima",'Fractured Land',80),
 ('Rabid Nihogg','Fractured Land',80),
 ('Third Unit Captain Karkoti','Lankusis Highland',80),
 ('Deputy Commander Vivajra','Kuriullu Valley',80),
 ('Rotten Root Meltlim','Mystic Spring of Anathe',80),
 ('Three-Horned Mino','Western Dartas Plains',80),
 ('Lamphus of Agony','Eastern Dartas Plains',80),
 ('Severed Wings Zvein','Eiron Hill',80),
 ('Superbia, Sacred Beast of Life','Eltnen Barrier Tower Ruins',80),
 ('Gluttonous Egetis','Eltnen Barrier Tower Ruins',80),
 ('Agglomerated Verenom','Ruberein Highland',80),
 ('Old Boss Vigor','Ruberein Highland',80),
]
BOSSES=[*(Boss(n,'Verteron',loc,l,m) for n,loc,l,m in _VERTERON),
        *(Boss(n,'Eltnen',loc,l,None) for n,loc,l in _ELTNEN)]
BY_KEY={b.key:b for b in BOSSES}
assert len(BOSSES)==36 and len(BY_KEY)==36
MAP_LINKS={
 'Verteron':'https://metabot.gg/en/aion-2/map/verteron/field-bosses',
 'Eltnen':'https://metabot.gg/en/aion-2/map/eltnen/field-bosses',
}
