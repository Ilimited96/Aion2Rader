"""Opt-in HTTPS update checking. Never auto-exec unverified downloads.
A publisher-operated manifest is needed: no update host has been configured yet.
"""
import hashlib, json, re, shutil, sys, tempfile, urllib.request, zipfile
from pathlib import Path
from urllib.parse import urlparse

MAX_MANIFEST=65536
MAX_ZIP=100*1024*1024

def version_tuple(v):
    raw=str(v).strip().lstrip('vV')
    if not re.fullmatch(r'\d+(\.\d+){0,3}',raw): raise ValueError('Invalid version')
    return tuple(int(x) for x in (raw.split('.')+['0']*4)[:4])

def https_url(url):
    p=urlparse(url)
    return p.scheme=='https' and bool(p.hostname) and not p.username and not p.password

def check_manifest(url, current_version):
    if not https_url(url): raise ValueError('Update source must be HTTPS')
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Aion2Rader/2.1'}),timeout=12) as r:
        payload=r.read(MAX_MANIFEST+1)
    if len(payload)>MAX_MANIFEST: raise ValueError('Manifest too large')
    obj=json.loads(payload)
    ver=obj['version']; dl=obj['download_url']; digest=obj['sha256']
    version_tuple(ver)
    if not https_url(dl): raise ValueError('Download URL must be HTTPS')
    if not re.fullmatch(r'[a-fA-F0-9]{64}',digest): raise ValueError('Invalid SHA256')
    return {'version':str(ver),'download_url':dl,'sha256':digest.lower(),
            'notes':str(obj.get('notes',''))[:1500],
            'newer':version_tuple(ver)>version_tuple(current_version)}

def safe_extract_package(zip_path, dest):
    """Extract a bounded ZIP; forbid path traversal, symlinks, and out-of-root files."""
    dest=Path(dest)
    if dest.exists(): raise FileExistsError(dest)
    temp=dest.with_name(dest.name+'.partial')
    if temp.exists(): shutil.rmtree(temp)
    total=0
    try:
        temp.mkdir(parents=True)
        with zipfile.ZipFile(zip_path) as z:
            entries=z.infolist()
            if len(entries)>400: raise ValueError('Too many update files')
            for entry in entries:
                pieces=Path(entry.filename.replace('\\','/')).parts
                if not pieces or any(x in ('','.', '..') for x in pieces) or entry.filename.startswith(('/', '\\')) or ':' in pieces[0]:
                    raise ValueError('Unsafe ZIP path')
                if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('ZIP symlink is forbidden')
                total+=entry.file_size
                if total>MAX_ZIP: raise ValueError('Update uncompressed size is too large')
                out=temp.joinpath(*pieces)
                if entry.is_dir():out.mkdir(parents=True,exist_ok=True)
                else:
                    out.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(entry) as src, out.open('wb') as f:shutil.copyfileobj(src,f)
        # Must contain runnable code in root or one parent folder.
        candidates=[temp,*[p for p in temp.iterdir() if p.is_dir()]]
        root=next((p for p in candidates if (p/'tracker.py').exists() or (p/'Aion2Rader.exe').exists()),None)
        if not root: raise ValueError('Package must contain tracker.py or Aion2Rader.exe')
        if root!=temp:
            for item in list(root.iterdir()):shutil.move(str(item),str(temp/item.name))
            root.rmdir()
        temp.replace(dest)
    except Exception:
        if temp.exists():shutil.rmtree(temp)
        raise
    return dest

def download_package(manifest,destination):
    destination=Path(destination)
    url=manifest['download_url']
    if not https_url(url):raise ValueError('HTTPS required')
    digest=hashlib.sha256()
    bytes_read=0
    destination.parent.mkdir(parents=True,exist_ok=True)
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Aion2Rader/2.1'}),timeout=25) as resp, destination.open('wb') as f:
            while True:
                chunk=resp.read(65536)
                if not chunk:break
                bytes_read+=len(chunk)
                if bytes_read>MAX_ZIP:raise ValueError('Download too large')
                digest.update(chunk);f.write(chunk)
        if digest.hexdigest()!=manifest['sha256']:
            raise ValueError('Update checksum does not match. Not installing.')
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return destination
