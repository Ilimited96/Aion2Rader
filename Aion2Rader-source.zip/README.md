# Aion2Rader — Update V2.1

**Unofficial AION 2 Global event companion for Windows 10 / Windows 11.** Not affiliated with NCSOFT. Requires **Python 3.11+** for the script edition. No third-party Python packages are required to run it.

## Install Update V2.1

1. Close Aion2Rader Update V2.0.
2. Extract the **new** ZIP with **Right click → Extract All**. Do not try to start the program from inside a ZIP.
3. Open the extracted `Aion2Rader` folder.
4. Double-click `Start_Aion2Rader.bat`.
5. Use **Overview** to view the new fantasy dashboard. Click **Test LIVE alert** to test notifications.

Your saved favorites, region, alert preferences, and manually recorded boss timers are stored in `%APPDATA%\Aion2Rader\settings.json`; **they are reused automatically** when you launch V2.1. You can keep your older V2.0 folder as a fallback.

**Build a Windows executable:** Double-click `Build_Aion2Rader_EXE.bat` on your Windows computer. It uses PyInstaller and may require internet access. The finished standalone program is `dist\Aion2Rader.exe`. The ZIP does not contain a precompiled EXE.

## Changes in Update V2.1

- **Every-second countdowns** on the main dashboard, Event schedule, Elyos field-boss list, selected boss, and floating overlay. Multi-day timers now also display seconds. Lists update countdown **cells in place** rather than rebuilding constantly.
- **Illustrated fantasy interface:** ornate gold-edged event illustrations, blue/gold palette, large hero countdown cards, top navigation, LIVE event cards, searchable Elyos world-boss dashboard, boss details, and a Map links tab.
- **Improved overlay:** Four event rows, with LIVE NOW indicator, semi-transparent always-on-top window.
- **Fantasy notification art** for LIVE/event/boss alerts; sound behavior retained.
- **Responsive layout improvements** for smaller Windows desktop sizes.
- **No change to saved settings format:** V2.0 favorites and manual spawn estimates remain intact.

## World Bosses

Open **World Bosses**, select a boss, then **Favorite / unfavorite**. Only the 36 Elyos field bosses from Verteron and Eltnen appear. Favorite sorting, region filters, and search are also available on Overview. Double-click a boss row to toggle its favorite star.

To track an estimated respawn, select the boss and click **Record kill NOW**; for bosses without a known respawn period, supply minutes yourself. Counts are estimates, **not live server data**. They are calculated from your entered kill time and period. Use **Map** to open external Elyos boss maps in your browser.

## Alerts

Open **Settings** and enable:

- `Enable event reminders`
- `Popup when an event goes LIVE`
- `Play alert sound`
- `Alert for favorite world-boss estimates`

Click **Test LIVE popup** (in Settings) or **Test LIVE alert** (on Overview) to check the popups. Borderless Windowed mode works better than exclusive fullscreen for notifications.

## Updates and important limitations

The **Updates** page provides an update check and an installer that verifies the SHA-256 checksum of any remote release package. It can also import a manually downloaded update ZIP. **Automatic downloads require a trusted HTTPS release manifest to be hosted first; no update server is included or configured.** `manifest.example.json` describes the release format.

Recurring events are calculated from community-observed schedules. Schedule hours may shift with patches or server-specific rules; correct times through the Events page and verify all events inside AION 2. The software does not inspect game memory, automate gameplay, or verify whether an event is actually running on the server.

### Data and sources

- Global schedules: <https://shugo.gg/timers> ; <https://aion2db.online/timeline?region=GLOBAL> ; <https://aion2data.com/timers>
- Verteron: <https://metabot.gg/en/aion-2/map/verteron/field-bosses>
- Eltnen: <https://metabot.gg/en/aion-2/map/eltnen/field-bosses>
- Community respawn estimates: <https://aion2.grimvane.app/companion/wiki/timers/>

Art shown inside the application was created from the illustrative UI concept developed for this project. It is decorative and does not indicate live game state.
