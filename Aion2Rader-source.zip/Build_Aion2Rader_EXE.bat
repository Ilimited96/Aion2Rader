@echo off
setlocal
cd /d "%~dp0"
title Aion2Rader EXE Builder
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install pyinstaller
if errorlevel 1 goto :error
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name Aion2Rader --icon "assets\aion2rader.ico" --add-data "assets;assets" --add-data "zones;zones" --add-data "README.md;." tracker.py
if errorlevel 1 goto :error
if exist "dist\Aion2Rader.exe" (
  echo.
  echo SUCCESS: dist\Aion2Rader.exe
  explorer "%~dp0dist"
)
pause
exit /b 0
:error
echo ERROR: EXE build failed. Check Python, pip and internet connection.
pause
exit /b 1
