# Aion2Rader Updates

## Update V2.1 — 18 October 2026
- New illustrated fantasy Overview layout with top navigation, paired hero cards, LIVE activity cards, and an integrated Elyos boss list + detail controls.
- Every visible countdown now updates once per second without a full list redraw every 8 seconds.
- Multi-day countdowns display seconds (`2d 03:12:09`) rather than only minutes.
- Boss timer controls stay visible at smaller window heights.
- Event row LIVE NOW colors update immediately on event start.
- Map page with external community boss-region links.
- Redesigned four-event floating overlay and more visual notification popups.
- Keeps compatible settings and favorites from V2.0.

## Update V2.0 — 18 October 2026
- Elyos-only 36 field-boss presets, favorite sorting, manual boss respawn estimates, favorite alerts.
- Blue-and-gold app, software update menu, version history.

## Update V1.1
- LIVE NOW popup with sound, extra reminders.

## Update V1.0
- Initial countdowns, regions, event calendar, .ics export.
