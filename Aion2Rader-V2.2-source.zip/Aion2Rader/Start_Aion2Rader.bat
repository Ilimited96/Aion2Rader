@echo off
setlocal
cd /d "%~dp0"
title Aion2Rader - Update V2.2
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 tracker.py
) else (
  python tracker.py
)
if errorlevel 1 (
  echo Could not start Aion2Rader. Install Python 3.11+ from python.org.
  pause
)
endlocal
