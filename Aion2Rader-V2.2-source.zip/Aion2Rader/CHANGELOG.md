# Aion2Rader release notes

## Update V2.2.0 — Windows setup, auto-update and uninstall
- Windows Setup build project with Start menu/Desktop shortcuts and Windows Installed Apps registration.
- An **Uninstall** button inside Updates for installed copies, with optional saved-data deletion.
- Optional start-up update checking from a configured public HTTPS release source.
- User-approved downloads of verified setup installers; an external helper installs after the running EXE closes and relaunches the new version.
- Local Setup EXE / ZIP import support; better error messages for source-only ZIPs.
- Preserves all Elyos boss favorites, settings, estimated respawn timers and popup notifications.

## Update V2.1.0
- Per-second event and boss countdowns; fantasy dashboard and improved mini overlay.

## Update V2.0.0
- Aion2Rader name, fantasy blue-and-gold UI, Elyos-only boss index, favorites and manual boss timers.

## Update V1.1.0
- Event LIVE NOW popups and sound alerts.

## Update V1.0.0
- Initial Global event schedule.
