import os,sys,time
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from tracker import App
app=App();app.update()
for pg in ['World Bosses','Events','Calendar','Settings','Updates','Overview']:
 app.show_page(pg);app.update()
 assert app.page==pg
app.show_page('World Bosses');app.update()
assert len(app._boss_row)==36,(len(app._boss_row))
app.selected_boss=next(b for b in __import__('bossdata').BOSSES if b.name=='High Commander Lagta')
app.var_boss_minutes.set('720');app.mark_kill();app.update()
assert app.boss_deadline(app.selected_boss)>time.time()
app.toggle_favorite();assert app.selected_boss.key in app.state['favorites']
app.toggle_favorite();assert app.selected_boss.key not in app.state['favorites']
app.clear_boss_timer();assert app.boss_deadline(app.selected_boss) is None
app.show_page('Overview');app.update()
from PIL import ImageGrab
try:
 im=ImageGrab.grab();im.save(os.path.join(os.path.dirname(__file__),'..','preview_v2.png'))
 print('SCREENSHOT OK',im.size)
except Exception as e: print('Screen capture unavailable',e)
app.exit();print('Smoke test passed')
