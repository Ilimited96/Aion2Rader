$ErrorActionPreference = 'Stop'
$install = Join-Path $env:RUNNER_TEMP 'Aion2Rader-installed'
$env:APPDATA = Join-Path $env:RUNNER_TEMP 'Aion2Rader-test-data'
New-Item -ItemType Directory -Force "$env:APPDATA/Aion2Rader" | Out-Null
$settings = "$env:APPDATA/Aion2Rader/settings.json"
'{"favorites":[],"region":"Europe (EU)","auto_check_updates":false,"test_marker":"preserve-me"}' | Set-Content $settings
$setup = (Resolve-Path installer/Aion2Rader_Setup_v2.2.0.exe).Path
function Run-Setup {
  $p = Start-Process $setup -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/NOICONS',('/DIR="'+$install+'"')) -WindowStyle Hidden -PassThru -Wait
  if ($p.ExitCode -ne 0) { throw "Setup exit $($p.ExitCode)" }
  if (-not (Test-Path "$install/unins000.exe")) { throw 'Uninstaller missing' }
}
function Wait-App {
  for ($i=0; $i -lt 60; $i++) {
    $apps = @(Get-Process Aion2Rader -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*Update V2.2.0*' })
    if ($apps.Count -gt 0) { return }
    Start-Sleep -Seconds 1
  }
  throw 'Installed app did not show its V2.2.0 window'
}
function Close-App {
  Get-Process Aion2Rader -ErrorAction SilentlyContinue | ForEach-Object { [void]$_.CloseMainWindow() }
  Start-Sleep -Seconds 3
  if (@(Get-Process Aion2Rader -ErrorAction SilentlyContinue).Count -gt 0) { throw 'App did not close cleanly' }
}
Run-Setup
Start-Process "$install/Aion2Rader.exe" -WindowStyle Hidden
Wait-App
Close-App
Write-Output 'PASS: installer, installed application launch and clean shutdown'
$env:TEST_INSTALL = $install
$env:TEST_SETUP = $setup
$env:TEST_WORK = Join-Path $env:RUNNER_TEMP 'updater-handoff'
@'
import os,sys
from pathlib import Path
import updater
sys.frozen=True
sys.executable=str(Path(os.environ['TEST_INSTALL'])/'Aion2Rader.exe')
updater.launch_windows_installer(os.environ['TEST_SETUP'],os.environ['TEST_WORK'])
'@ | Set-Content handoff_test.py
python handoff_test.py
Wait-App
Close-App
if (Test-Path "$env:TEST_WORK/last_install_error.txt") { throw (Get-Content "$env:TEST_WORK/last_install_error.txt" -Raw) }
if ((Get-Content $settings -Raw | ConvertFrom-Json).test_marker -ne 'preserve-me') { throw 'Update lost settings' }
Write-Output 'PASS: updater helper reinstalled, restarted and preserved settings'
$p = Start-Process "$install/unins000.exe" -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -WindowStyle Hidden -PassThru -Wait
if ($p.ExitCode -ne 0) { throw "Uninstall exit $($p.ExitCode)" }
if (Test-Path "$install/Aion2Rader.exe") { throw 'Uninstall left executable' }
if ((Get-Content $settings -Raw | ConvertFrom-Json).test_marker -ne 'preserve-me') { throw 'Uninstall removed settings' }
Write-Output 'PASS: uninstaller removed application and kept settings'
