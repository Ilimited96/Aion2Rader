# Aion2Rader — Update V2.2 (Windows)

An unofficial AION 2 Global companion: event countdowns, LIVE popups, 36 Elyos field bosses, favorite alerts, manual boss respawn estimates, event calendar and floating timer. **It does not connect to game servers** and does not automate gameplay. Community event times can be wrong.

## What changed in V2.2

- **Windows Setup installer and registered uninstaller:** an Inno Setup package installs Aion2Rader into the current user's Windows profile. It creates an entry in **Settings > Apps > Installed apps** and provides `unins000.exe` for the app's **Updates > Uninstall** button.
- **Updates from inside the installed app:** optionally check a public HTTPS manifest at launch, get notified when there is a newer version, approve it, and download a **Windows Setup EXE** with a SHA-256 integrity check. A helper waits until the app exits, runs the installer, and reopens Aion2Rader after success.
- **Manual updates:** Updates > Local ZIP / Setup accepts a trusted Setup EXE, a ZIP containing one, or an imported portable app. A source-only Python ZIP **cannot** update an existing frozen EXE.
- **Keep or remove your data at uninstall:** an uninstall launched inside the installed app lets you decide whether to delete `%APPDATA%\Aion2Rader` (settings, favorites and boss kill timestamps). Standard Windows Settings uninstall **keeps** that data so a future reinstall can reuse it.
- All V2.1 countdown, alert, Elyos-only and fantasy UI features are preserved.

## How to run V2.2 now (Python edition)

1. Close the V2.1 window.
2. Extract this whole ZIP to a **new** directory.
3. Double-click `Start_Aion2Rader.bat` in the extracted `Aion2Rader` folder. Requires Python 3.11+ on Windows 10/11.
4. All user settings remain in `%APPDATA%\Aion2Rader` and will load automatically.

## How to create the *installed* Windows edition (one-time setup)

1. Install Python if needed, from https://www.python.org/downloads/windows/.
2. In this folder, double-click `Build_Aion2Rader_EXE.bat`. The compiled portable EXE appears in `dist\Aion2Rader.exe`.
3. Install **Inno Setup 6** from https://jrsoftware.org/isinfo.php (free). This is required only to create the setup installer, not to run Aion2Rader.
4. Double-click `Build_Windows_Setup.bat`. It creates `installer\Aion2Rader_Setup_v2.2.0.exe`.
5. **Run the setup EXE.** Once installed, launch Aion2Rader using its Start menu shortcut, not the Python `.bat`. The **Updates > Uninstall Aion2Rader…** button will now work.

**Important:** This ZIP contains source and build tools, **not** a prebuilt Windows installer. Because Windows compilation is not available in the current build environment, your PC must run these build steps once, or someone you trust must publish an installer for you. The app itself works in Python mode without Inno Setup, but its uninstall button will explain portable removal instead of uninstalling automatically.

## How future updates work without rebuilding the EXE on your PC

Aion2Rader can **check** for new versions automatically, but only after someone publishes signed/trusted releases to a permanent online location. The software currently has **no configured update server**. A hosted update is never assumed or fabricated.

Suggested hosting workflow: a **public GitHub repository** that contains the files from this `Aion2Rader` folder, including `.github/workflows/windows-release.yml`.

1. Create a public GitHub repository, e.g. `YOUR_USERNAME/Aion2Rader`. Upload the source files, folders and workflow in this package.
2. Publish a new **Git tag** `v2.2.0` matching `VERSION` in `tracker.py`. The included GitHub Actions workflow builds the standalone Windows EXE, installs Inno Setup on the CI runner, creates a Setup EXE, prepares `release.json` with the actual installer SHA-256, and publishes both to GitHub Releases. (The workflow must have Contents: read and write permission.)
3. In the installed app, open **Updates** and set **Update Server** to:
   `https://github.com/YOUR_USERNAME/Aion2Rader/releases/latest/download/release.json`
4. Enable **Automatically check for new versions at startup**. When Update V2.3 is published to that same repository later, the app can offer to download and install it. You can also click **Check for updates** at any time.
5. On future releases, increment `VERSION` and update `Aion2Rader_Setup.iss` (or use the workflow `/DMyAppVersion` override), push a matching tag and let CI build the installer. You do **not** need to rebuild the app yourself on your own Windows PC for each release.

**Security:** Use only a GitHub repo you control or trust. HTTPS and a SHA-256 hash from the same manifest verify download integrity, **not publisher identity**. Do not run software from unverified release pages. Windows may display an Unknown publisher SmartScreen warning for unsigned installer builds. Commercial code signing is optional but recommended before distributing the app.

If you prefer to publish releases manually rather than use GitHub Actions, run `publish_release.py --repository OWNER/REPO --installer installer/Aion2Rader_Setup_v2.2.0.exe` after building the Setup EXE, and upload its output `installer/release.json` and the Setup EXE as assets **on the same GitHub release tag**.

## Uninstall choices

- **Installed Windows edition:** Updates > **Uninstall Aion2Rader…** or Windows Settings > Apps > Installed apps > Aion2Rader > Uninstall. The app's button asks whether you wish to also erase its saved data. By default saved data is retained.
- **Portable or Python edition:** Close the app and delete its extracted folder (or the `Aion2Rader.exe` you copied manually). Optional: delete `%APPDATA%\Aion2Rader` to erase favorites/settings. If in doubt, **keep** the settings folder.

## Sources and limitations

- Global schedules: https://shugo.gg/timers ; https://aion2db.online/timeline?region=GLOBAL
- Elyos bosses: https://metabot.gg/en/aion-2/map/verteron/field-bosses ; https://metabot.gg/en/aion-2/map/eltnen/field-bosses

Elyos field-boss respawn countdowns are calculated from **manually recorded kills**. The app has not been tested against live AION 2 servers. Windows installer + auto-update hand-off is implemented and code-tested, but requires testing end-to-end on Windows with a published installer and release URL.
