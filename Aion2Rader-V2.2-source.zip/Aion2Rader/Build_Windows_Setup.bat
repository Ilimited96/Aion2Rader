@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Aion2Rader Windows Setup Builder - Update V2.2
if not exist "dist\Aion2Rader.exe" (
  echo Standalone EXE is missing. Building it first...
  call "%~dp0Build_Aion2Rader_EXE.bat"
  if errorlevel 1 goto :error
)
set "COMPILER="
where ISCC.exe >nul 2>&1
if not errorlevel 1 set "COMPILER=ISCC.exe"
if not defined COMPILER if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "COMPILER=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined COMPILER if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "COMPILER=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined COMPILER (
  echo.
  echo You need Inno Setup 6 to create a Windows installer with an Uninstall option.
  echo Download it from: https://jrsoftware.org/isinfo.php
  echo Then run this batch file again.
  pause
  exit /b 1
)
"%COMPILER%" "Aion2Rader_Setup.iss"
if errorlevel 1 goto :error
if exist "installer\Aion2Rader_Setup_v2.2.0.exe" (
  echo.
  echo SUCCESS: installer\Aion2Rader_Setup_v2.2.0.exe
  echo Install using this SETUP file, not the portable EXE.
  explorer "%~dp0installer"
)
pause
exit /b 0
:error
echo.
echo Setup build failed. Check the messages above.
pause
exit /b 1
