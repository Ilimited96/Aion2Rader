"""Command Center preview using the existing Windows application's logic.

Launch with Python + Pillow. Production settings are used only with --use-settings;
the default preview stores its state in a separate workspace profile.
"""
from __future__ import annotations
import os, sys, time
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont
from PIL import Image, ImageTk, ImageOps

if '--use-settings' not in sys.argv:
    os.environ['APPDATA'] = str(Path(__file__).parent/'preview-profile')

import tracker
from tracker import BG, PANEL, CARD, CARD2, GOLD, BLUE, TEXT, MUTED, GREEN, FONT, BASE
from engine import clock, REGIONS
from bossdata import BOSSES, BY_KEY, boss_map_url

LINE = '#1C3A50'


class OutlinedOverlayLabel(tk.Canvas):
    """Native text with an opaque dark stroke, independent of panel opacity."""
    def __init__(self,parent,text,font,fg,bg,wraplength=0,justify='left',width=None,anchor='w'):
        self._text_options=dict(text=text,font=font,fg=fg,wraplength=wraplength,justify=justify)
        self._fixed_width=(tkfont.Font(font=font).measure('0')*width+4) if width else None
        super().__init__(parent,bg=bg,highlightthickness=0,bd=0,takefocus=False)
        self._draw_text()

    def _draw_text(self):
        self.delete('all')
        options=self._text_options
        common=dict(text=options['text'],font=options['font'],anchor='nw',
                    width=options['wraplength'],justify=options['justify'])
        self.create_text(4,4,fill='#000000',**common)
        for dx,dy in ((-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)):
            self.create_text(2+dx,2+dy,fill='#000000',**common)
        main=self.create_text(2,2,fill=options['fg'],**common)
        box=self.bbox(main)
        if box:
            super().configure(width=self._fixed_width or box[2]+3,height=box[3]+3)

    def configure(self,cnf=None,**kw):
        if isinstance(cnf,dict):kw={**cnf,**kw};cnf=None
        changed=False
        for name in list(kw):
            if name in self._text_options:
                self._text_options[name]=kw.pop(name);changed=True
        result=super().configure(cnf,**kw) if cnf is not None or kw else None
        if changed:self._draw_text()
        return result

    config=configure

    def cget(self,key):
        return self._text_options[key] if key in self._text_options else super().cget(key)


class CommandCenter(tracker.App):
    def __init__(self):
        self._photos = {}
        self._image_sources = {}
        self._resize_jobs = {}
        super().__init__()
        self.title(f'Aion2Rader | Update V{tracker.VERSION} | Elyos' if '--use-settings' in sys.argv else 'Aion2Rader | Command Center design preview'+(' | Reference view' if '--reference-view' in sys.argv else '')+(' | Styled tabs' if '--review-tabs' in sys.argv else ''))
        self.geometry('1536x990+40+30')
        self.minsize(1200,760)

    def recalculate(self):
        if '--reference-view' not in sys.argv:return super().recalculate()
        self._reference_now=datetime(2026,10,18,3,50,53).timestamp()
        self.state['favorites']=['Verteron:High Commander Lagta']
        self.events=[]
        for i,(name,category,hour,minute) in enumerate([
            ('Shugo Festival','Festival',4,0),('Dimensional Invasion','Invasion',4,30),
            ('Shugo Festival','Festival',5,0),('Spacetime Rift','Rift',5,0),('Dimensional Invasion','Invasion',5,30)]):
            self.events.append(dict(id=f'visual-fixture:{i}',name=name,category=category,
                                   when=datetime(2026,10,18,hour,minute).timestamp(),duration=300,
                                   detail='Design comparison fixture',reliability='Preview fixture'))
        self.last_calc=time.time();self.refresh_page()

    def maybe_auto_update(self):
        if '--use-settings' in sys.argv:return super().maybe_auto_update()

    def _styles(self):
        super()._styles()
        s=ttk.Style(self)
        s.configure('Command.Treeview', background=BG, fieldbackground=BG,
                    foreground=TEXT, borderwidth=0, relief='flat',
                    rowheight=76, font=(FONT,-18))
        s.configure('Command.Treeview.Heading', background='#0D263D',
                    foreground='#C5DCEF', font=(FONT,-12), padding=(8,17), relief='flat')
        s.map('Command.Treeview',background=[('selected','#173B56')], foreground=[('selected',TEXT)])
        s.layout('Command.Treeview',[('Treeview.treearea',{'sticky':'nswe'})])
        s.configure('Boss.Treeview',background=BG,fieldbackground=BG,
                    foreground=TEXT,rowheight=34,borderwidth=0,font=(FONT,-14))
        s.configure('Boss.Treeview.Heading',background='#0D263D',foreground='#C5DCEF',
                    font=(FONT,-11),padding=(6,13),relief='flat')
        s.map('Boss.Treeview',background=[('selected','#12314B')],foreground=[('selected',TEXT)])
        s.layout('Boss.Treeview',[('Treeview.treearea',{'sticky':'nswe'})])
        s.configure('Page.Treeview',background=BG,fieldbackground=BG,foreground=TEXT,
                    rowheight=49,borderwidth=0,font=(FONT,-15))
        s.configure('Page.Treeview.Heading',background='#0D263D',foreground='#C5DCEF',
                    font=(FONT,-12),padding=(10,16),relief='flat')
        s.map('Page.Treeview',background=[('selected','#173B56')],foreground=[('selected',TEXT)])
        s.layout('Page.Treeview',[('Treeview.treearea',{'sticky':'nswe'})])
        # Clam's default active heading is white. Keep every table header dark
        # during hover and press, including the inherited schedule screens.
        for heading in ('Command.Treeview.Heading','Boss.Treeview.Heading','Page.Treeview.Heading','R.Treeview.Heading'):
            s.map(heading,
                  background=[('pressed','#1A415C'),('active','#143650')],
                  foreground=[('pressed',GOLD),('active',TEXT)],
                  relief=[('pressed','flat'),('active','flat')])
        s.configure('Command.TCombobox',background='#0C2237',fieldbackground='#0C2237',
                    foreground=TEXT,arrowcolor=GOLD,bordercolor=LINE,padding=8,font=(FONT,-13))
        s.map('Command.TCombobox',fieldbackground=[('readonly','#0C2237')],foreground=[('readonly',TEXT)])

    def ui(self,parent,text,size=14,color=TEXT,bold=False,bg=None,**kw):
        return tk.Label(parent,text=text,bg=bg or parent.cget('bg'),fg=color,
                        font=(FONT,-size,'bold' if bold else 'normal'),bd=0,**kw)

    def overlay_label(self,parent,text,size=14,color=TEXT,bold=False,**kw):
        return OutlinedOverlayLabel(parent,text=text,fg=color,bg=parent.cget('bg'),
                                    font=(FONT,-size,'bold' if bold else 'normal'),**kw)

    def image(self,name,size,fit=True):
        key=(name,*size,fit)
        if key not in self._photos:
            path=BASE/'assets'/name
            if not path.is_file(): return None
            if name not in self._image_sources:
                self._image_sources[name]=Image.open(path).convert('RGBA')
            src=self._image_sources[name]
            if name=='hero_boss.png':
                src=src.crop((int(src.width*.67),0,src.width,src.height))
            out=ImageOps.fit(src,size,method=Image.Resampling.LANCZOS) if fit else ImageOps.contain(src,size,method=Image.Resampling.LANCZOS)
            self._photos[key]=ImageTk.PhotoImage(out,master=self)
        return self._photos[key]

    def icon(self,name,size=22,color='pale'):
        return self.image('ui_'+name+'_'+color+'.png',(size,size),False)

    def action(self,parent,text,command,primary=False,icon=None,width=None):
        kw=dict(text=text,command=command,bg=GOLD if primary else '#102B43',
                fg=BG if primary else TEXT,activebackground='#F6D694' if primary else '#20425D',
                activeforeground=BG if primary else TEXT,relief='flat',bd=0,
                font=(FONT,-14,'bold'),cursor='hand2',padx=18,pady=13,compound='left')
        if icon:
            kw['image']=self.icon(icon,20,'dark' if primary else 'pale')
            kw['text']='  '+text
        if width:kw['width']=width
        return tk.Button(parent,**kw)

    def box(self,parent):
        return tk.Frame(parent,bg=BG,highlightbackground=LINE,highlightthickness=1)

    def panel(self,parent,color=PANEL,**kw):
        return tk.Frame(parent,bg=color,highlightbackground=LINE,highlightthickness=1,**kw)

    def button(self,parent,title,callback,primary=False,compact=False):
        button=self.action(parent,title,callback,primary)
        if compact:button.configure(pady=10)
        return button

    def entry(self,parent,var,width=30):
        return tk.Entry(parent,textvariable=var,bg='#0C2237',fg=TEXT,insertbackground=GOLD,
                        relief='flat',highlightbackground=LINE,highlightcolor=BLUE,
                        highlightthickness=1,width=width,font=(FONT,-14))

    def combo(self,parent,var,values,width=20):
        return ttk.Combobox(parent,textvariable=var,values=values,state='readonly',width=width,
                            style='Command.TCombobox',font=(FONT,-14))

    def ornate_heading(self,parent,title,subtitle=''):
        banner=tk.Canvas(parent,bg='#07192B',height=135,highlightthickness=0)
        banner.pack(fill='x',pady=(0,20))
        bg=banner.create_image(0,0,anchor='nw')
        banner.create_text(24,27,text=title.replace(' · Elyos Only',''),fill=GOLD,font=('Georgia',-30),anchor='nw')
        banner.create_text(26,78,text=subtitle,fill='#C4D9E7',font=(FONT,-14),anchor='nw',tags='subtitle')
        def resize(event):
            if event.width<2:return
            banner.itemconfigure(bg,image=self.image('fantasy_header.png',(event.width,135)))
            banner.itemconfigure('subtitle',width=max(250,event.width-440))
            banner.tag_lower(bg)
        banner.bind('<Configure>',resize)

    def row_tree(self,parent,columns,heights=10):
        hold=self.box(parent);hold.pack(fill='both',expand=True,pady=(0,7))
        tree=ttk.Treeview(hold,columns=tuple(k for k,_,_ in columns),show='headings',
                          style='Page.Treeview',height=heights,selectmode='browse')
        for key,label,width in columns:
            tree.heading(key,text=label,anchor='w')
            tree.column(key,width=width,minwidth=34 if key=='fav' else 65,anchor='w',
                        stretch=key==('name' if any(c[0]=='name' for c in columns) else columns[0][0]))
        scroll=ttk.Scrollbar(hold,orient='vertical',command=tree.yview,style='R.Vertical.TScrollbar')
        scroll.pack(side='right',fill='y');tree.configure(yscrollcommand=scroll.set)
        tree.pack(fill='both',expand=True,padx=(9,0),pady=5)
        tree.tag_configure('live',foreground=GREEN);tree.tag_configure('near',foreground=BLUE)
        tree.tag_configure('muted',foreground='#758495')
        return tree

    def page_events(self):
        self.ornate_heading(self.body,'Event schedule','Plan your next adventure. Filter the schedule and manage your reminders.')
        filters=tk.Frame(self.body,bg=BG);filters.pack(fill='x',pady=(0,18))
        for title,var,values,width in [
            ('EVENT TYPE',self.var_event_filter,['All events','Festival','Invasion','Rift','Bosses','Sieges','PvP','Resets','Deadline','Field Boss','Personal'],20),
            ('TIME RANGE',self.var_period,['Next 12 hours','Next 24 hours','Next 7 days'],19)]:
            group=tk.Frame(filters,bg=BG);group.pack(side='left',padx=(0,14))
            self.ui(group,title,10,MUTED,True).pack(anchor='w',pady=(0,6))
            c=self.combo(group,var,values,width);c.pack(fill='x')
            c.bind('<<ComboboxSelected>>',lambda e:self.refresh_page())
        search=tk.Frame(filters,bg=BG);search.pack(side='left',fill='x',expand=True)
        self.ui(search,'SEARCH EVENTS',10,MUTED,True).pack(anchor='w',pady=(0,6))
        self.entry(search,self.var_event_search).pack(fill='x',ipady=10)
        self.var_event_search.trace_add('write',lambda *_:self.refresh_page() if self.page=='Events' else None)
        content=tk.Frame(self.body,bg=BG);content.pack(fill='both',expand=True)
        listing=tk.Frame(content,bg=BG);listing.pack(side='left',fill='both',expand=True,padx=(0,18))
        self.event_tree=self.row_tree(listing,[('name','EVENT',230),('kind','CATEGORY',110),('time','LOCAL TIME',165),('left','STARTS IN',120)],9)
        self.event_tree.bind('<<TreeviewSelect>>',lambda e:self.show_event_detail())
        detail=tk.Frame(content,bg=BG,width=280)
        detail.pack(side='right',fill='y');detail.pack_propagate(False)
        self.ui(detail,'SELECTED EVENT',11,GOLD,True).pack(anchor='w',padx=20,pady=(22,12))
        self.event_selected_name=self.ui(detail,'Choose an event',22,TEXT,True,wraplength=240,justify='left')
        self.event_selected_name.pack(anchor='w',padx=20,pady=(0,12))
        self.event_detail=self.ui(detail,'Select a row to see its schedule and reminder controls.',13,MUTED,wraplength=240,justify='left')
        self.event_detail.pack(anchor='w',padx=20,pady=(0,20))
        for label,callback in [('Mute / unmute reminder',self.mute_event),
                               ('Adjust event time',self.shift_event),('Delete personal event',self.delete_personal_event)]:
            button=self.button(detail,label,callback)
            button.configure(bg=BG,fg=GOLD if callback==self.mute_event else TEXT,
                             activebackground='#102237',highlightthickness=1,
                             highlightbackground=LINE,highlightcolor=GOLD)
            button.pack(fill='x',padx=18,pady=5)
        self._event_row={}

    def show_event_detail(self):
        event=self.selected_event()
        if event:
            self.event_selected_name.configure(text=event['name'])
            self.event_detail.configure(text=datetime.fromtimestamp(event['when']).strftime('%a %d %b · %H:%M')+'\n\n'+event['reliability']+'\n\n'+event['detail'])

    def page_world_bosses(self):
        heading=tk.Frame(self.body,bg=BG);heading.pack(fill='x',pady=(4,16))
        self.ui(heading,'WORLD BOSSES',19,GOLD,True).pack(side='left')
        self.ui(heading,'36 bosses  ·  Verteron & Eltnen',12,MUTED).pack(side='right')
        filters=self.panel(self.body,'#0A1D2D');filters.pack(fill='x',pady=(0,16))
        filter_fields=tk.Frame(filters,bg='#0A1D2D');filter_fields.pack(fill='x',padx=16,pady=14)
        group=tk.Frame(filter_fields,bg='#0A1D2D');group.pack(side='left',padx=(0,18))
        self.ui(group,'SHOW BOSSES',11,MUTED,True).pack(anchor='w',pady=(0,6))
        select=self.combo(group,self.var_boss_filter,['All Elyos bosses','★ Favorites only','Verteron only','Eltnen only'],22)
        select.pack(fill='x');select.bind('<<ComboboxSelected>>',lambda e:self.refresh_page())
        search=tk.Frame(filter_fields,bg='#0A1D2D');search.pack(side='left',fill='x',expand=True)
        self.ui(search,'SEARCH BY NAME OR LOCATION',11,MUTED,True).pack(anchor='w',pady=(0,6))
        self.entry(search,self.var_boss_search).pack(fill='x',ipady=8)
        self.var_boss_search.trace_add('write',lambda *_:self.refresh_page() if self.page=='World Bosses' else None)
        top=tk.Frame(self.body,bg=BG);top.pack(fill='both',expand=True)
        side=self.box(top);side.pack(side='right',fill='y')
        viewport=tk.Canvas(side,bg='#091C2C',width=320,highlightthickness=0)
        scrollbar=ttk.Scrollbar(side,orient='vertical',command=viewport.yview,style='R.Vertical.TScrollbar')
        scrollbar.pack(side='right',fill='y')
        viewport.pack(side='left',fill='both',expand=True)
        viewport.configure(yscrollcommand=scrollbar.set)
        details=tk.Frame(viewport,bg='#091C2C')
        window=viewport.create_window(0,0,window=details,anchor='nw',width=320)
        details.bind('<Configure>',lambda e:viewport.configure(scrollregion=viewport.bbox('all')))
        viewport.bind('<Configure>',lambda e:viewport.itemconfigure(window,width=e.width))
        self.boss_details_viewport=viewport
        self.ui(details,'SELECTED BOSS',11,GOLD,True).pack(anchor='w',padx=20,pady=(20,12))
        self.boss_name=self.ui(details,'Select a boss',24,TEXT,True,wraplength=280,justify='left')
        self.boss_name.pack(anchor='w',padx=20,pady=(0,8))
        self.boss_area=self.ui(details,'',14,MUTED,wraplength=280,justify='left')
        self.boss_area.pack(anchor='w',padx=20)
        timer=self.panel(details,'#0B2234');timer.pack(fill='x',padx=18,pady=(20,18))
        self.ui(timer,'RESPAWN TIMER',10,GOLD,True).pack(anchor='w',padx=14,pady=(13,5))
        self.boss_countdown=self.ui(timer,'No timer',28,BLUE,True)
        self.boss_countdown.pack(anchor='w',padx=14,pady=(0,13))
        self.ui(details,'RESPAWN INTERVAL · MINUTES',10,MUTED,True).pack(anchor='w',padx=20,pady=(0,7))
        self.entry(details,self.var_boss_minutes,12).pack(fill='x',padx=20,ipady=9)
        self.ui(details,'Record a kill to start the countdown.',12,MUTED,wraplength=280).pack(anchor='w',padx=20,pady=(7,10))
        self.button(details,'Record kill',self.mark_kill,True).pack(fill='x',padx=20,pady=(0,8))
        self.button(details,'Show boss on map',self.open_boss_map).pack(fill='x',padx=20,pady=(0,14))
        tools=tk.Frame(details,bg='#091C2C');tools.pack(fill='x',padx=20)
        self.boss_favorite_button=self.button(tools,'Favorite',self.toggle_favorite,compact=True)
        self.boss_favorite_button.pack(side='left',fill='x',expand=True,padx=(0,5))
        self.button(tools,'Clear timer',self.clear_boss_timer,compact=True).pack(side='left',fill='x',expand=True,padx=(5,0))
        self.boss_estimate_note=self.ui(details,'',11,MUTED,wraplength=280,justify='left')
        self.boss_estimate_note.pack(anchor='w',padx=20,pady=(18,5))
        self.ui(details,'Community estimates · Verify in-game',11,MUTED,wraplength=280,justify='left').pack(anchor='w',padx=20,pady=(0,18))
        for widget in [viewport,details,*details.winfo_children()]:
            widget.bind('<MouseWheel>',lambda e:viewport.yview_scroll(int(-e.delta/120),'units'))
        listing=tk.Frame(top,bg=BG);listing.pack(side='left',fill='both',expand=True,padx=(0,18))
        self.boss_tree=self.row_tree(listing,[('fav','',34),('name','BOSS',230),('region','REGION',100),('timer','NEXT SPAWN',145)],12)
        self.boss_tree.bind('<<TreeviewSelect>>',lambda e:self.boss_selection())
        self.boss_tree.bind('<Double-1>',lambda e:self.toggle_favorite())
        self._boss_row={}
        if self.selected_boss:self.draw_boss_detail()

    def draw_boss_detail(self):
        super().draw_boss_detail()
        b=self.selected_boss
        if b is None:return
        self.boss_name.configure(text=b.name)
        self.boss_area.configure(text=f'{b.location}\n{b.region} · Level {b.level}')
        self.boss_favorite_button.configure(text='★ Favorited' if b.key in self.state['favorites'] else '☆ Favorite')
        self.boss_estimate_note.configure(text=f'Default interval: {b.minutes} minutes.' if b.minutes else 'Interval unconfirmed. Enter your own estimate.')

    def page_settings(self):
        self.ornate_heading(self.body,'Make it yours','Choose your server schedule, reminders and the way Aion2Rader stays beside your game.')
        columns=tk.Frame(self.body,bg=BG);columns.pack(fill='both',expand=True)
        left=tk.Frame(columns,bg=BG);left.pack(side='left',fill='both',expand=True,padx=(0,18))
        right=tk.Frame(columns,bg=BG);right.pack(side='left',fill='both',expand=True)
        server=self.panel(left,'#091C2C');server.pack(fill='x',pady=(0,18))
        self.ui(server,'SERVER & SCHEDULE',12,GOLD,True).pack(anchor='w',padx=22,pady=(22,12))
        self.ui(server,'Your region',21,TEXT,True).pack(anchor='w',padx=22)
        self.ui(server,'Event times follow this server schedule.',13,MUTED).pack(anchor='w',padx=22,pady=(6,14))
        region=self.combo(server,self.var_region,list(REGIONS),26);region.pack(fill='x',padx=22,pady=(0,22))
        region.bind('<<ComboboxSelected>>',lambda e:(self.save(),self.recalculate()))
        display=self.panel(left,'#091C2C');display.pack(fill='x')
        self.ui(display,'WINDOW & OVERLAY',12,GOLD,True).pack(anchor='w',padx=22,pady=(22,12))
        self.check(display,'Keep window always on top',self.var_top,self.toggle_top).pack(anchor='w',padx=18,pady=(0,10))
        self.button(display,'Toggle floating overlay',self.toggle_mini).pack(fill='x',padx=22,pady=(0,22))
        self.button(display,'Reset overlay background',self.restore_overlay_visibility).pack(fill='x',padx=22,pady=(0,22))
        notifications=self.panel(right,'#091C2C');notifications.pack(fill='x')
        self.ui(notifications,'NOTIFICATIONS',12,GOLD,True).pack(anchor='w',padx=22,pady=(22,14))
        self.ui(notifications,'Be ready when it starts',21,TEXT,True).pack(anchor='w',padx=22,pady=(0,14))
        for label,var in [('Enable event reminders',self.var_alert),('Popup when an event goes live',self.var_live),
                          ('Play alert sound',self.var_sound),('Favorite boss spawn estimates',self.var_fav_alert)]:
            self.check(notifications,label,var,self.save).pack(anchor='w',padx=18,pady=5)
        row=tk.Frame(notifications,bg='#091C2C');row.pack(fill='x',padx=22,pady=(16,18))
        self.ui(row,'Remind me',14).pack(side='left',padx=(0,12))
        lead=self.combo(row,self.var_lead,['1','3','5','10','15','30'],5);lead.pack(side='left')
        lead.bind('<<ComboboxSelected>>',lambda e:self.save())
        self.ui(row,'minutes before',13,MUTED).pack(side='left',padx=12)
        buttons=tk.Frame(notifications,bg='#091C2C');buttons.pack(fill='x',padx=22,pady=(0,22))
        self.button(buttons,'Test event alert',lambda:self.notify('LIVE NOW · DEMO','Shugo Festival · Example notification',True),True).pack(side='left',padx=(0,10))
        self.button(buttons,'Test boss alert',lambda:self.notify('FAVORITE BOSS','Example boss notification')).pack(side='left')

    def page_map(self):
        self.map_view=None
        heading=tk.Frame(self.body,bg=BG);heading.pack(fill='x',pady=(4,14))
        self.ui(heading,'BOSS LOCATIONS',19,GOLD,True).pack(side='left')
        self.ui(heading,'Elyos · Interactive map',12,MUTED).pack(side='right')
        toolbar=self.panel(self.body,'#0A1D2D');toolbar.pack(fill='x',pady=(0,12))
        fields=tk.Frame(toolbar,bg='#0A1D2D');fields.pack(fill='x',padx=16,pady=14)
        fields.columnconfigure(1,weight=1)
        region_field=tk.Frame(fields,bg='#0A1D2D');region_field.grid(row=0,column=0,sticky='ew',padx=(0,16))
        self.ui(region_field,'REGION',11,MUTED,True).pack(anchor='w',pady=(0,6))
        self.map_region=tk.StringVar(value=getattr(self,'_map_region','Verteron'))
        region=self.combo(region_field,self.map_region,['Verteron','Eltnen'],17)
        region.pack(fill='x')
        region.bind('<<ComboboxSelected>>',lambda e:self.load_map_region())
        boss=getattr(self,'_map_boss',None)
        boss_picker=tk.Frame(fields,bg='#0A1D2D');boss_picker.grid(row=0,column=1,sticky='ew',padx=(0,16))
        self.ui(boss_picker,'BOSS',11,MUTED,True).pack(anchor='w',pady=(0,6))
        self.map_boss_choice=tk.StringVar(value=boss.name if boss else 'Choose a boss…')
        self.map_boss_combo=self.combo(boss_picker,self.map_boss_choice,
            sorted(b.name for b in BOSSES if b.region==self.map_region.get()),30)
        self.map_boss_combo.pack(fill='x')
        self.map_boss_combo.bind('<<ComboboxSelected>>',lambda e:self.locate_map_boss())
        self.action(fields,'Show on map',self.load_map_region,True,icon='map').grid(row=0,column=2,sticky='s')
        selected=tk.Frame(self.body,bg=BG);selected.pack(fill='x',pady=(0,12))
        self.ui(selected,'SELECTED BOSS',10,GOLD,True).pack(anchor='w',pady=(0,4))
        self.map_context=self.ui(selected,boss.name if boss else 'Explore '+self.map_region.get(),22,TEXT,True)
        self.map_context.pack(anchor='w')
        self.map_location=self.ui(selected,f'{boss.location}  ·  Level {boss.level}' if boss else 'Select a skull on the map to see boss details.',13,MUTED)
        self.map_location.pack(anchor='w',pady=(3,0))
        map_tools=tk.Frame(self.body,bg=BG);map_tools.pack(fill='x',pady=(0,8))
        self.ui(map_tools,'Drag to move  ·  Scroll to zoom  ·  Click a skull for details',12,MUTED).pack(side='left')
        self.map_filters_button=self.button(map_tools,'Map filters',self.toggle_map_filters,compact=True)
        self.map_filters_button.pack(side='right',padx=(8,0))
        self.button(map_tools,'Reload',self.load_map_region,compact=True).pack(side='right')
        self.map_host=self.panel(self.body,'#091C2C');self.map_host.pack(fill='both',expand=True)
        self.map_hint=self.ui(self.map_host,'Choose a boss, then Show on map.',15,MUTED)
        self.map_hint.pack(pady=35)
        # Delay native browser creation until the frame has a real size. Merely
        # visiting other tabs in regression tests must not make network requests.
        if getattr(self,'_open_map_on_show',False):
            self._open_map_on_show=False
            self.after_idle(self.load_map_region)

    def open_boss_map(self):
        boss=self.selected_boss
        if boss is None:return
        self._map_boss=boss
        self._map_region=boss.region
        self._open_map_on_show=True
        self.show_page('Map')

    def locate_map_boss(self):
        choice=self.map_boss_choice.get()
        boss=BY_KEY.get(choice) or next((b for b in BOSSES if b.name==choice and b.region==self.map_region.get()),None)
        if boss is None:return
        self.selected_boss=boss
        self._map_boss=boss
        self.map_region.set(boss.region)
        self.load_map_region()

    def toggle_map_filters(self):
        if self.map_view is None:return
        self._map_filters_visible=not getattr(self,'_map_filters_visible',False)
        self.map_filters_button.configure(text='Hide filters' if self._map_filters_visible else 'Map filters')
        value='open' if self._map_filters_visible else 'closed'
        self.map_view.eval("document.querySelector('[data-aion-map-only]')?.setAttribute('data-aion-filters','"+value+"');window.dispatchEvent(new Event('resize'));")

    def load_map_region(self):
        if self.page!='Map' or not self.map_host.winfo_exists():return
        self._map_region=self.map_region.get()
        if self._map_region not in tracker.MAP_LINKS:return
        boss=getattr(self,'_map_boss',None)
        selected=boss if boss and boss.region==self._map_region else None
        self.map_boss_combo.configure(values=sorted(b.name for b in BOSSES if b.region==self._map_region))
        self.map_boss_choice.set(selected.name if selected else 'Choose a boss…')
        self.map_context.configure(text=selected.name if selected else 'Explore '+self._map_region)
        self.map_location.configure(text=f'{selected.location}  ·  Level {selected.level}' if selected else 'Select a skull on the map to see boss details.')
        self._map_filters_visible=False
        self.map_filters_button.configure(text='Map filters')
        try:
            if self.map_view is None:
                from embedded_map import EmbeddedMap
                self.map_view=EmbeddedMap(self.map_host)
                self.map_hint.pack_forget()
                self.map_view.pack(fill='both',expand=True)
            self.map_view.navigate(boss_map_url(boss) if boss and boss.region==self._map_region
                else tracker.MAP_LINKS[self._map_region])
        except Exception:
            self.map_hint.configure(text='The map viewer could not start. Microsoft Edge WebView2 is required.\nYou can retry with Load map after the viewer is available.')
            self.map_hint.pack(pady=35)

    def toggle_mini(self):
        if self.mini is not None:
            try:self.mini.destroy()
            except tk.TclError:pass
            background=getattr(self,'mini_background',None)
            if background is not None:
                try:background.destroy()
                except tk.TclError:pass
            self.mini_background=None
            self.mini=None
            return
        # Separate the fading plate from the always-opaque text/controls. A
        # whole-window alpha would also fade the countdown and event names.
        transparent_key='#010203'
        background=tk.Toplevel(self)
        background.title('Aion2Rader · Overlay background')
        background.overrideredirect(True)
        background.configure(bg=LINE)
        background.attributes('-topmost',True)
        self.mini_background=background
        plate=tk.Frame(background,bg='#071827')
        plate.pack(fill='both',expand=True,padx=1,pady=1)
        background_header=tk.Frame(plate,bg='#0C2337',height=34)
        background_header.pack(fill='x')
        self.mini_background_header=background_header
        m=tk.Toplevel(self)
        self.mini=m
        m.title('Aion2Rader · Floating Events')
        m.configure(bg=LINE)
        m.overrideredirect(True)
        m.attributes('-topmost',True)
        m.attributes('-transparentcolor',transparent_key)
        width,height=320,296
        x=max(0,min(self.winfo_rootx()+self.winfo_width()-width-28,self.winfo_screenwidth()-width-20))
        y=max(0,self.winfo_rooty()+148)
        m.geometry(f'{width}x{height}+{x}+{y}')
        background.geometry(f'{width}x{height}+{x}+{y}')
        shell=tk.Frame(m,bg='#071827');shell.pack(fill='both',expand=True,padx=1,pady=1)
        header=tk.Frame(shell,bg='#0C2337',height=34);header.pack(fill='x');header.pack_propagate(False)
        emblem=tk.Label(header,image=self.image('command_emblem.png',(23,23),False),bg='#0C2337')
        emblem.pack(side='left',padx=(12,8),pady=4)
        title=self.overlay_label(header,'AION2RADER',13,GOLD,True);title.pack(side='left')
        close=tk.Button(header,image=self.icon('x',17),command=self.toggle_mini,bg='#0C2337',
                        activebackground='#193B53',relief='flat',bd=0,padx=10,pady=7,cursor='hand2',takefocus=True)
        close.pack(side='right',padx=3)
        self.mini_close_button=close
        self._mini_drag=None
        def start_drag(event):
            self._mini_drag=(event.x_root-m.winfo_x(),event.y_root-m.winfo_y())
        def drag(event):
            if self._mini_drag:
                dx,dy=self._mini_drag
                nx=max(0,min(event.x_root-dx,m.winfo_screenwidth()-m.winfo_width()))
                ny=max(0,min(event.y_root-dy,m.winfo_screenheight()-m.winfo_height()))
                m.geometry(f'+{nx}+{ny}')
        for widget in (header,emblem,title):
            widget.configure(cursor='fleur')
            widget.bind('<ButtonPress-1>',start_drag)
            widget.bind('<B1-Motion>',drag)
            widget.bind('<ButtonRelease-1>',lambda e:setattr(self,'_mini_drag',None))
        def background_press(event):
            # Transparent pixels in the foreground pass mouse input through.
            # Handle that input here instead of using a disabled window (which
            # makes Windows beep), including the transparent close-button padding.
            left,top=close.winfo_rootx(),close.winfo_rooty()
            if left<=event.x_root<left+close.winfo_width() and top<=event.y_root<top+close.winfo_height():
                self.toggle_mini()
                return 'break'
            m.lift()
            start_drag(event)
            return 'break'
        self._overlay_start_drag=start_drag
        self._overlay_drag_to=drag
        self._overlay_background_press=background_press
        for widget in (background,plate,background_header):
            widget.configure(cursor='fleur')
            widget.bind('<ButtonPress-1>',background_press)
            widget.bind('<B1-Motion>',drag)
            widget.bind('<ButtonRelease-1>',lambda e:setattr(self,'_mini_drag',None))
        hero=tk.Frame(shell,bg='#071827');hero.pack(fill='x',padx=14,pady=(6,5))
        self.mini_kind=self.overlay_label(hero,'NEXT EVENT',11,GOLD,True);self.mini_kind.pack(anchor='w')
        self.mini_name=self.overlay_label(hero,'Loading events…',20,TEXT,True,wraplength=290,justify='left')
        self.mini_name.pack(anchor='w',pady=(3,0))
        self.mini_count=self.overlay_label(hero,'00:00:00',34,BLUE,True);self.mini_count.pack(anchor='w',pady=(0,0))
        self.mini_time=self.overlay_label(hero,'',13,'#E9F1F9');self.mini_time.pack(anchor='w')
        tk.Frame(shell,bg=LINE,height=1).pack(fill='x',padx=14,pady=(0,3))
        self.mini_rows=[]
        for _ in range(2):
            row=tk.Frame(shell,bg='#071827');row.pack(fill='x',padx=14,pady=2)
            name=self.overlay_label(row,'',14,TEXT,True,anchor='w',width=1)
            timer=self.overlay_label(row,'',14,BLUE,True);timer.pack(side='right',padx=(8,0))
            name.pack(side='left',fill='x',expand=True)
            self.mini_rows.append((name,timer))
        self.overlay_label(shell,'Local schedule · Estimated times',11,TEXT).pack(anchor='w',padx=14,pady=(3,4))
        opacity_row=tk.Frame(shell,bg='#071827')
        opacity_row.pack(side='bottom',fill='x',padx=(14,30),pady=(0,9))
        self.overlay_label(opacity_row,'Background',12,TEXT,True).pack(side='left',padx=(0,10))
        try:opacity=max(0,min(100,int(self.state.get('overlay_opacity',100))))
        except (ValueError,TypeError):opacity=100
        self.overlay_opacity=tk.IntVar(value=opacity)
        self.opacity_readout=self.overlay_label(opacity_row,f'{opacity}%',12,TEXT,True,width=4)
        self.opacity_readout.pack(side='right')
        style=ttk.Style(self)
        style.configure('Overlay.Horizontal.TScale',background=transparent_key,troughcolor='#15354B',
                        bordercolor=GOLD,lightcolor=GOLD,darkcolor=GOLD)
        style.map('Overlay.Horizontal.TScale',background=[('active',GOLD),('!active',GOLD)])
        self.opacity_slider=ttk.Scale(opacity_row,from_=0,to=100,orient='horizontal',
                                      variable=self.overlay_opacity,command=self.set_overlay_opacity,
                                      length=160,style='Overlay.Horizontal.TScale',cursor='hand2',takefocus=True)
        self.opacity_slider.pack(side='left',fill='x',expand=True)
        def clear_surfaces(widget):
            if isinstance(widget,(tk.Toplevel,tk.Frame,tk.Label,tk.Button,OutlinedOverlayLabel)):
                widget.configure(bg=transparent_key)
            for child in widget.winfo_children():clear_surfaces(child)
        clear_surfaces(m)
        # A colour-keyed empty edge is click-through, so provide a real hit
        # target along the right edge and a separate visible resize handle.
        self.mini_move_grip=tk.Frame(m,bg=transparent_key,cursor='fleur')
        self.mini_move_grip.place(relx=1.0,x=-1,y=35,anchor='ne',width=5,relheight=1.0,height=-59)
        for widget in (hero,self.mini_kind,self.mini_name,self.mini_count,self.mini_time,self.mini_move_grip):
            widget.configure(cursor='fleur')
            widget.bind('<ButtonPress-1>',start_drag)
            widget.bind('<B1-Motion>',drag)
            widget.bind('<ButtonRelease-1>',lambda e:setattr(self,'_mini_drag',None))
        self.mini_resize_grip=tk.Label(m,image=self.icon('resize',17),bg=transparent_key,cursor='size_nw_se')
        self.mini_resize_grip.place(relx=1.0,rely=1.0,x=-3,y=-3,anchor='se',width=20,height=20)
        self._mini_resize=None
        def start_resize(event):
            self._mini_resize=(event.x_root,event.y_root,m.winfo_width(),m.winfo_height())
        def resize(event):
            if self._mini_resize:
                sx,sy,original_w,original_h=self._mini_resize
                w=max(300,min(original_w+event.x_root-sx,m.winfo_screenwidth()-m.winfo_x()))
                h=max(296,min(original_h+event.y_root-sy,m.winfo_screenheight()-m.winfo_y()))
                m.geometry(f'{w}x{h}')
        self._overlay_start_resize=start_resize
        self._overlay_resize_to=resize
        self.mini_resize_grip.bind('<ButtonPress-1>',start_resize)
        self.mini_resize_grip.bind('<B1-Motion>',resize)
        self.mini_resize_grip.bind('<ButtonRelease-1>',lambda e:setattr(self,'_mini_resize',None))
        def sync_background(event):
            if event.widget is m and background.winfo_exists():
                background.geometry(f'{m.winfo_width()}x{m.winfo_height()}+{m.winfo_x()}+{m.winfo_y()}')
                self.mini_name.configure(wraplength=max(240,m.winfo_width()-30))
                background.lower(m)
        def clean_background(event):
            if event.widget is m:
                try:background.destroy()
                except tk.TclError:pass
                self.mini_background=None
                if self.mini is m:self.mini=None
        m.bind('<Configure>',sync_background)
        m.bind('<Destroy>',clean_background)
        self.set_overlay_opacity(opacity)
        m.bind('<Escape>',lambda e:self.toggle_mini())
        m.protocol('WM_DELETE_WINDOW',self.toggle_mini)
        self.refresh_mini(time.time())
        background.lower(m)
        m.lift()

    def set_overlay_opacity(self,value):
        percent=max(0,min(100,round(float(value))))
        self.state['overlay_opacity']=percent
        if hasattr(self,'overlay_opacity') and self.overlay_opacity.get()!=percent:
            self.overlay_opacity.set(percent)
        if self.mini is not None and self.mini.winfo_exists():
            self.mini.attributes('-alpha',1.0)
            background=getattr(self,'mini_background',None)
            if background is not None and background.winfo_exists():
                background.attributes('-alpha',percent/100)
            if hasattr(self,'opacity_readout') and self.opacity_readout.winfo_exists():
                self.opacity_readout.configure(text=f'{percent}%')
        if getattr(self,'_opacity_save_job',None):
            self.after_cancel(self._opacity_save_job)
        self._opacity_save_job=self.after(250,self._save_opacity)

    def _save_opacity(self):
        self._opacity_save_job=None
        self.save()

    def restore_overlay_visibility(self):
        self.set_overlay_opacity(100)
        if self.mini is None:self.toggle_mini()
        else:self.mini.lift()

    def refresh_mini(self,now):
        if self.mini is None or not self.mini.winfo_exists():return
        now=getattr(self,'_reference_now',now)
        events=[e for e in self.events if e['id'] not in self.state['muted']]
        live=[e for e in events if e['duration']>0 and e['when']<=now<e['when']+e['duration']]
        upcoming=[e for e in events if e['when']>now]
        featured=next(iter(live or upcoming),None)
        if featured:
            is_live=featured in live
            self.mini_kind.configure(text='LIVE EVENT' if is_live else 'NEXT EVENT',fg=GREEN if is_live else GOLD)
            self.mini_name.configure(text=featured['name'])
            deadline=featured['when']+featured['duration'] if is_live else featured['when']
            self.mini_count.configure(text=clock(deadline-now),fg=GREEN if is_live else BLUE)
            self.mini_time.configure(text=('Ends at ' if is_live else 'Starts at ')+datetime.fromtimestamp(deadline).strftime('%H:%M'))
        else:
            self.mini_kind.configure(text='EVENT RADAR',fg=GOLD)
            self.mini_name.configure(text='No upcoming events')
            self.mini_count.configure(text='—',fg=BLUE);self.mini_time.configure(text='Check your Events filters and schedule.')
        remaining=[e for e in live+upcoming if featured is None or e['id']!=featured['id']]
        for index,(name,timer) in enumerate(self.mini_rows):
            event=remaining[index] if index<len(remaining) else None
            name.configure(text=event['name'][:28] if event else '')
            active=event is not None and event['when']<=now
            timer.configure(text=('LIVE NOW' if active else clock(event['when']-now)) if event else '',fg=GREEN if active else BLUE)

    def _chrome(self):
        self.sidebar=tk.Canvas(self,bg='#041321',width=248,highlightthickness=0,takefocus=True)
        self.sidebar.pack(side='left',fill='y')
        self.sidebar.pack_propagate(False)
        self.side_bg=self.sidebar.create_image(0,0,anchor='nw')
        self.side_crest=self.sidebar.create_image(124,54,anchor='center')
        self.sidebar.create_text(124,104,text='A I O N 2 R A D E R',fill=GOLD,
                                font=('Georgia',-24),anchor='center')
        self.sidebar.create_text(124,130,text='E V E N T  R A D A R   ·   E L Y O S',
                                fill=BLUE,font=(FONT,-9,'bold'))
        self.nav_buttons={}
        self.nav_markers={}
        self._nav_hover=None
        self._nav_focus=0
        for i,(name,icon) in enumerate([('Overview','home'),('Events','calendar'),('World Bosses','crown'),
                                      ('Calendar','calendar-days'),('Map','map'),('Settings','settings'),('Updates','download')]):
            y=182+i*59
            image_id=self.sidebar.create_image(37,y+29,image=self.icon(icon,23))
            text_id=self.sidebar.create_text(84,y+29,text=name,fill=TEXT,font=(FONT,-15),anchor='w')
            self.nav_buttons[name]=(text_id,image_id,icon)
            self.nav_markers[name]=self.sidebar.create_rectangle(0,y,5,y+58,fill=GOLD,outline='',state='hidden')
        self.nav_focus_ring=self.sidebar.create_rectangle(10,189,238,232,outline=GOLD,width=1,state='hidden')
        self.sidebar.bind('<Motion>',self._nav_motion)
        self.sidebar.bind('<Leave>',lambda e:self._nav_motion(None))
        self.sidebar.bind('<Button-1>',self._nav_click)
        self.sidebar.bind('<Up>',lambda e:self._nav_key(-1))
        self.sidebar.bind('<Down>',lambda e:self._nav_key(1))
        self.sidebar.bind('<Return>',self._nav_activate)
        self.sidebar.bind('<space>',self._nav_activate)
        self.sidebar.bind('<FocusIn>',lambda e:self._draw_nav_focus())
        self.sidebar.bind('<FocusOut>',lambda e:self.sidebar.itemconfigure(self.nav_focus_ring,state='hidden'))
        self.sidebar.bind('<Configure>',self._resize_sidebar)
        main=tk.Frame(self,bg=BG)
        main.pack(side='left',fill='both',expand=True)
        head=tk.Frame(main,bg=BG,height=103)
        head.pack(fill='x');head.pack_propagate(False)
        self.header_crest=tk.Label(head,bg=BG)
        self.header_crest.place(x=30,y=19,width=42,height=44)
        self.heading=tk.Label(head,text='Your next adventure',bg=BG,fg=GOLD,font=('Georgia',-31))
        self.heading.place(x=83,y=18)
        self.subtitle=self.ui(head,'Plan your events and track boss timers — Aion2Rader for Elyos.',15,MUTED)
        self.subtitle.place(x=85,y=60)
        self.region_label=self.ui(head,'Europe (EU)    |    Local time',12,MUTED)
        self.region_label.place(relx=1,x=-22,y=24,anchor='ne')
        self.now_label=self.ui(head,'',14,TEXT,True)
        self.now_label.place(relx=1,x=-22,y=48,anchor='ne')
        self.body=tk.Frame(main,bg=BG)
        self.body.pack(fill='both',expand=True,padx=20,pady=(0,8))
        foot=tk.Frame(main,bg=BG,height=25)
        foot.pack(fill='x');foot.pack_propagate(False)
        self.status=self.ui(foot,'Community schedules · Not connected to game servers',10,MUTED)
        self.status.pack(side='left',padx=20)
        self.ui(foot,'V'+tracker.VERSION+(' · ELYOS' if '--use-settings' in sys.argv else ' · DESIGN PREVIEW'),10,MUTED).pack(side='right',padx=20)
        self.bind('<Configure>',self._adapt_height,add='+')

    def _adapt_height(self,event):
        if event.widget is not self or not hasattr(self,'hero') or not self.hero.winfo_exists():return
        h=max(230,min(302,int((event.height-10)*.31)))
        self.hero.configure(height=h)
        ratio=h/302
        self.hero.coords(self.hero_name,28,64*ratio)
        self.hero.itemconfigure(self.hero_name,font=(FONT,-max(29,int(38*ratio)),'bold'))
        self.hero.coords(self.hero_timer,28,118*ratio)
        self.hero.itemconfigure(self.hero_timer,font=(FONT,-max(48,int(69*ratio)),'bold'))
        self.hero.coords(self.hero_sub,31,h-98)
        self.hero.itemconfigure(self.hero_sub,font=(FONT,-max(16,int(20*ratio))))
        self.hero.coords(self.hero_reminder,28,h-60)

    def _resize_sidebar(self,event):
        if event.width<2 or event.height<2:return
        key='sidebar'
        if key in self._resize_jobs:self.after_cancel(self._resize_jobs[key])
        self._resize_jobs[key]=self.after(75,lambda:self._paint_sidebar(event.width,event.height))

    def _paint_sidebar(self,w,h):
        self.sidebar.itemconfigure(self.side_bg,image=self.image('command_sidebar.png',(w,h)))
        self.sidebar.itemconfigure(self.side_crest,image=self.image('command_emblem.png',(105,64),False))
        self.header_crest.configure(image=self.image('command_emblem.png',(42,42),False))
        self.sidebar.tag_lower(self.side_bg)

    def _nav_at(self,event):
        if event is None or not 0<=event.x<248:return None
        index=(event.y-182)//59
        return list(self.nav_buttons)[index] if 0<=index<len(self.nav_buttons) else None

    def _paint_nav(self):
        for name,(text_id,image_id,icon) in self.nav_buttons.items():
            active=name==self.page or name==self._nav_hover
            self.sidebar.itemconfigure(text_id,fill=GOLD if active else TEXT)
            self.sidebar.itemconfigure(image_id,image=self.icon(icon,23,'gold' if active else 'pale'))
            self.sidebar.itemconfigure(self.nav_markers[name],state='normal' if name==self.page else 'hidden')

    def _nav_motion(self,event):
        name=self._nav_at(event)
        if name!=self._nav_hover:
            self._nav_hover=name;self._paint_nav()
        self.sidebar.configure(cursor='hand2' if name else '')

    def _nav_click(self,event):
        name=self._nav_at(event)
        if name:
            self._nav_focus=list(self.nav_buttons).index(name)
            self.sidebar.focus_set();self.show_page(name);self._draw_nav_focus()

    def _draw_nav_focus(self):
        y=182+self._nav_focus*59
        self.sidebar.coords(self.nav_focus_ring,10,y+7,238,y+51)
        self.sidebar.itemconfigure(self.nav_focus_ring,state='normal')

    def _nav_key(self,direction):
        self._nav_focus=(self._nav_focus+direction)%len(self.nav_buttons)
        self._draw_nav_focus()
        return 'break'

    def _nav_activate(self,event=None):
        self.show_page(list(self.nav_buttons)[self._nav_focus])
        return 'break'

    def show_page(self,page):
        self.page=page
        self._paint_nav()
        for name in self.nav_buttons:
            self.sidebar.itemconfigure(self.nav_markers[name],state='normal' if name==page else 'hidden')
        for w in self.body.winfo_children():w.destroy()
        self.heading.configure(text='Your next adventure' if page=='Overview' else page)
        self.subtitle.configure(text='Plan your events and track boss timers — Aion2Rader for Elyos.' if page=='Overview' else 'Aion2Rader · Elyos event companion')
        getattr(self,'page_'+page.lower().replace(' ','_'))()
        self.refresh_page()

    def page_overview(self):
        stage=tk.Frame(self.body,bg=BG);stage.pack(fill='both',expand=True)
        self.hero=tk.Canvas(stage,bg='#07192B',height=302,highlightbackground='#8B6B38',highlightthickness=1)
        self.hero.pack(fill='x',pady=(0,18))
        self.hero_bg=self.hero.create_image(0,0,anchor='nw')
        self.hero.create_text(28,25,text='NEXT EVENT',fill=GOLD,font=(FONT,-17,'bold'),anchor='nw')
        self.hero_name=self.hero.create_text(28,64,text='Loading…',fill=TEXT,font=(FONT,-38,'bold'),anchor='nw')
        self.hero_timer=self.hero.create_text(28,118,text='00:00:00',fill=BLUE,font=(FONT,-69,'bold'),anchor='nw')
        self.hero_sub=self.hero.create_text(31,204,text='',fill='#D2E7F4',font=(FONT,-20),anchor='nw')
        remind=self.action(self.hero,'Reminder settings',lambda:self.show_page('Settings'),icon='bell')
        self.hero_reminder=self.hero.create_window(28,242,anchor='nw',window=remind,height=43)
        self.hero.bind('<Configure>',self._resize_hero)
        lower=tk.Frame(stage,bg=BG);lower.pack(fill='both',expand=True)
        lower.columnconfigure(0,weight=54,uniform='bottom');lower.columnconfigure(1,weight=46,uniform='bottom')
        lower.rowconfigure(0,weight=1)
        events=self.box(lower);events.grid(row=0,column=0,sticky='nsew',padx=(0,7))
        event_head=tk.Frame(events,bg=BG);event_head.pack(fill='x',padx=16,pady=(17,15))
        self.ui(event_head,'UPCOMING EVENTS',20,GOLD,True).pack(side='left')
        self.ui(event_head,'All times are local',11,MUTED).pack(side='right')
        cols=('name','start','in')
        self.ov_tree=ttk.Treeview(events,columns=cols,show='tree headings',style='Command.Treeview',selectmode='browse',height=5)
        self.ov_tree.heading('#0',text='');self.ov_tree.column('#0',width=52,minwidth=52,stretch=False)
        for key,title,width in [('name','EVENT',240),('start','LOCAL TIME',105),('in','STARTS IN',120)]:
            self.ov_tree.heading(key,text=title,anchor='w');self.ov_tree.column(key,width=width,minwidth=80,stretch=key=='name',anchor='w')
        self.ov_tree.pack(fill='both',expand=True,padx=13,pady=(0,13))
        self.ov_tree.tag_configure('live',foreground=GREEN);self.ov_tree.tag_configure('near',foreground=BLUE)
        self.ov_tree.bind('<Double-1>',lambda e:self.show_page('Events'))
        right=self.box(lower);right.grid(row=0,column=1,sticky='nsew',padx=(7,0))
        rh=tk.Frame(right,bg=BG);rh.pack(fill='x',padx=14,pady=(17,13))
        self.ui(rh,'WORLD BOSSES',20,GOLD,True).pack(side='left')
        self.ui(rh,'Elyos only',12,BLUE).pack(side='right')
        filters=tk.Frame(right,bg=BG);filters.pack(fill='x',padx=13,pady=(0,12))
        self.ov_boss_filter=tk.StringVar(value='All Elyos bosses')
        self.ov_boss_search=tk.StringVar(value='')
        f=ttk.Combobox(filters,textvariable=self.ov_boss_filter,values=['All Elyos bosses','★ Favorites only','Verteron only','Eltnen only'],
                       state='readonly',style='Command.TCombobox',width=20,font=(FONT,-13))
        f.pack(side='left',fill='x',expand=True,padx=(0,10))
        f.bind('<<ComboboxSelected>>',lambda e:self.draw_dashboard_bosses())
        search=tk.Entry(filters,textvariable=self.ov_boss_search,bg='#0C2237',fg=TEXT,insertbackground=GOLD,
                        font=(FONT,-13),relief='flat',width=16,highlightthickness=1,highlightbackground=LINE)
        search.pack(side='left',fill='x',expand=True,ipady=9)
        self.ov_boss_search.trace_add('write',lambda *_:self.draw_dashboard_bosses() if self.page=='Overview' else None)
        self.ov_boss_tree=ttk.Treeview(right,columns=('fav','name','region','timer'),show='tree headings',
                                    displaycolumns=('name','region','timer'),style='Boss.Treeview',height=5,selectmode='browse')
        self.ov_boss_tree.heading('#0',text='');self.ov_boss_tree.column('#0',width=42,minwidth=42,stretch=False)
        for key,label,width in [('fav','',30),('name','BOSS',170),('region','REGION',75),('timer','NEXT SPAWN',125)]:
            self.ov_boss_tree.heading(key,text=label,anchor='w');self.ov_boss_tree.column(key,width=width,minwidth=26 if key=='fav' else 62,stretch=key=='name',anchor='w')
        self.ov_boss_tree.pack(fill='both',expand=True,padx=13,pady=(0,12))
        self.ov_boss_tree.tag_configure('near',foreground=GOLD)
        self.ov_boss_tree.bind('<<TreeviewSelect>>',lambda e:self.dashboard_boss_selection())
        self.ov_boss_tree.bind('<Double-1>',lambda e:self.toggle_favorite())
        self.ov_boss_rows={}
        detail=tk.Frame(right,bg='#091C2C',highlightbackground='#8B6B38',highlightthickness=1)
        detail.pack(side='bottom',fill='x',padx=12,pady=(0,12),before=self.ov_boss_tree)
        art=self.image('hero_boss.png',(104,148))
        self.detail_art=tk.Label(detail,image=art,bg='#091C2C')
        self.detail_art.pack(side='left',padx=(12,14),pady=14)
        info=tk.Frame(detail,bg='#091C2C');info.pack(side='left',fill='both',expand=True,pady=13,padx=(0,12))
        self.ui(info,'SELECTED BOSS',11,GOLD).pack(anchor='w')
        self.ov_detail_name=self.ui(info,'High Commander Lagta',18,TEXT,True)
        self.ov_detail_name.pack(anchor='w',pady=(6,3))
        self.ov_detail_location=self.ui(info,'Verteron (Elyos)',11,MUTED)
        self.ov_detail_location.pack(anchor='w')
        self.ov_detail_timer=self.ui(info,'No timer recorded',17,BLUE,True)
        self.ov_detail_timer.pack(anchor='w',pady=(7,7))
        controls=tk.Frame(info,bg='#091C2C');controls.pack(fill='x')
        self.kill_button=self.action(controls,'Record kill',self.dashboard_mark_kill,True,icon='swords')
        self.kill_button.pack(side='left',fill='x',expand=True,padx=(0,8))
        self.action(controls,'Map',self.open_boss_map,icon='map').pack(side='left')
        def adapt_detail(event):
            if event.widget is not right:return
            if event.width<490:self.detail_art.pack_forget()
            elif not self.detail_art.winfo_manager():self.detail_art.pack(side='left',padx=(12,14),pady=14,before=info)
        right.bind('<Configure>',adapt_detail)
        if self.selected_boss is None:self.selected_boss=BY_KEY.get('Verteron:High Commander Lagta') or BOSSES[0]
        self.draw_dashboard_bosses()

    def draw_dashboard_bosses(self):
        super().draw_dashboard_bosses()
        if self.page=='Overview' and hasattr(self,'ov_boss_rows'):
            for row,boss in self.ov_boss_rows.items():
                self.ov_boss_tree.item(row,image=self.icon('star',17,'gold' if boss.key in self.state['favorites'] else 'pale'))

    def _resize_hero(self,e):
        if e.width>2:
            self.hero.itemconfigure(self.hero_bg,image=self.image('command_hero.png',(e.width,e.height)))
            self.hero.tag_lower(self.hero_bg)

    def draw_overview(self):
        now=getattr(self,'_reference_now',time.time())
        self.ov_tree.delete(*self.ov_tree.get_children())
        self._overview_rows={}
        for event in self.events:
            if event['when']+event['duration']<now or event['id'] in self.state['muted']:continue
            if len(self._overview_rows)>=5:break
            icon={'Festival':'icon_Festival.png','Invasion':'icon_Invasion.png','Rift':'icon_Rift.png'}.get(event['category'],'icon_Deadline.png')
            image=self.image(icon,(37,37),False)
            secs=event['when']-now
            row=self.ov_tree.insert('',tk.END,image=image,values=(event['name'],datetime.fromtimestamp(event['when']).strftime('%H:%M'),
                                     'LIVE NOW' if secs<=0 else clock(secs)),tags=('live' if secs<=0 else 'near',))
            self._overview_rows[row]=event
        self.draw_dashboard_bosses()
        self.update_visible_countdowns(now)

    def draw_dashboard_detail(self):
        if self.page!='Overview' or not hasattr(self,'ov_detail_name'):return
        b=self.selected_boss
        if b is None:return
        self.ov_detail_name.configure(text=b.name)
        self.ov_detail_location.configure(text=f'{b.region} (Elyos) · Level {b.level}')
        deadline=self.boss_deadline(b)
        self.ov_detail_timer.configure(text=clock(deadline-time.time()) if deadline else 'No timer recorded')

    def update_visible_countdowns(self,now):
        if self.page!='Overview':return super().update_visible_countdowns(now)
        if not hasattr(self,'hero') or not self.hero.winfo_exists():return
        now=getattr(self,'_reference_now',now)
        self.region_label.configure(text=self.var_region.get()+'    |    Local time')
        if '--reference-view' in sys.argv:
            self.now_label.configure(text='Sun 18 October 2026   03:50:53')
        active=self.active_event(now);event=active or self.next_event(now)
        self.hero.itemconfigure(self.hero_name,text=event['name'] if event else 'No event scheduled')
        self.hero.itemconfigure(self.hero_timer,text='LIVE NOW' if active else clock(event['when']-now) if event else '—',fill=GREEN if active else BLUE)
        self.hero.itemconfigure(self.hero_sub,text=('Ends at ' if active else 'Starts at ')+datetime.fromtimestamp(event['when']+event['duration'] if active else event['when']).strftime('%H:%M') if event else 'View the Events page')
        for row,event in self._overview_rows.items():
            if self.ov_tree.exists(row):
                secs=event['when']-now
                self.ov_tree.set(row,'in','LIVE NOW' if secs<=0<secs+event['duration'] else clock(secs) if secs>0 else 'ENDED')
        for row,b in getattr(self,'ov_boss_rows',{}).items():
            if self.ov_boss_tree.exists(row):
                deadline=self.boss_deadline(b)
                self.ov_boss_tree.set(row,'timer',clock(deadline-now) if deadline else 'No timer recorded')
        self.draw_dashboard_detail()


if __name__=='__main__':
    app=CommandCenter()
    initial=next((arg.split('=',1)[1] for arg in sys.argv if arg.startswith('--tab=')),'Overview')
    if initial in app.nav_buttons:app.show_page(initial)
    app.mainloop()
