#define MyAppName "Aion2Rader"
#ifndef MyAppVersion
#define MyAppVersion "2.3.0"
#endif
#define MyAppExeName "Aion2Rader.exe"

[Setup]
AppId={{8F5E7B38-11AA-443A-9E59-A6D2DE761A22}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} Update V{#MyAppVersion}
AppPublisher=Aion2Rader Community
UninstallDisplayName=Aion2Rader
UninstallDisplayIcon={app}\{#MyAppExeName}
DefaultDirName={localappdata}\Programs\Aion2Rader
DefaultGroupName=Aion2Rader
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=installer
OutputBaseFilename=Aion2Rader_Setup_v{#MyAppVersion}
SetupIconFile=assets\aion2rader.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
UsePreviousAppDir=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
Source: "dist\Aion2Rader.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Aion2Rader"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Aion2Rader"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Aion2Rader"; Flags: nowait postinstall skipifsilent
