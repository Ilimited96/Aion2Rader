"""Offline checks for boss identity, region switching and in-app routing."""
import sys,types,tkinter as tk
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from command_layout import CommandCenter
from bossdata import BOSSES,BY_KEY,MAP_MARKERS,boss_map_url

class MapSurface(tk.Frame):
    def navigate(self,url):self.url=url

assert set(MAP_MARKERS)=={boss.key for boss in BOSSES}
assert len(set(MAP_MARKERS.values()))==36
assert parse_qs(urlsplit(boss_map_url(BY_KEY['Verteron:High Commander Lagta'])).query)['focus']==['npc:2101131']
assert parse_qs(urlsplit(boss_map_url(BY_KEY['Eltnen:Rabid Nihogg'])).query)['focus']==['npc:2101349']
with patch.dict(sys.modules,{'embedded_map':types.SimpleNamespace(EmbeddedMap=MapSurface)}),patch('webbrowser.open',side_effect=AssertionError('External browser opened')):
    app=CommandCenter();app.withdraw()
    try:
        app.selected_boss=BY_KEY['Verteron:High Commander Lagta'];app.open_boss_map();app.update()
        assert app.page=='Map' and '2101131' in app.map_view.url
        app.map_boss_choice.set('Eltnen:Rabid Nihogg');app.locate_map_boss()
        assert app.map_region.get()=='Eltnen' and '2101349' in app.map_view.url
        assert 'Rabid Nihogg' in app.map_context.cget('text')
        app.map_region.set('Verteron');app.load_map_region()
        assert 'focus=' not in app.map_view.url  # Never focus the last boss in the wrong region.
        app.show_page('World Bosses');app.update()
    finally:
        for timer in app.tk.call('after','info'):app.after_cancel(timer)
        app.destroy()
print('PASS: all 36 marker identities, boss routing, region switching and no external browser')
