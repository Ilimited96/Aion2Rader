"""Run with: python tests/test_updater_v22.py"""
from pathlib import Path
import sys,hashlib,io,json,os,tempfile,unittest,zipfile
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import updater

class Response(io.BytesIO):
    def __init__(self,data,url):
        super().__init__(data);self._url=url
    def geturl(self):return self._url
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

class Tests(unittest.TestCase):
    def test_versions_and_repository(self):
        self.assertTrue(updater.version_tuple('2.3.0')>updater.version_tuple('2.2'))
        self.assertEqual(updater.github_latest_manifest('MyUser/Aion2Rader'),'https://github.com/MyUser/Aion2Rader/releases/latest/download/release.json')
        for bad in ('../../hello','bad','owner/repo/branch'):
            with self.assertRaises(ValueError):updater.github_latest_manifest(bad)

    def test_manifest_and_redirect_validation(self):
        url='https://github.com/owner/repo/releases/latest/download/release.json'
        m={'version':'2.3.0','installer_url':'https://github.com/o/r/releases/download/v2.3.0/Aion2Rader_Setup_v2.3.0.exe','sha256':'0'*64,'notes':'Feature release'}
        with patch.object(updater.urllib.request,'urlopen',return_value=Response(json.dumps(m).encode(),url)):
            self.assertTrue(updater.check_manifest(url,'2.2.0')['newer'])
        with patch.object(updater.urllib.request,'urlopen',return_value=Response(json.dumps(m).encode(),'http://unsafe.local')):
            with self.assertRaises(ValueError):updater.check_manifest(url,'2.2.0')
        with self.assertRaises(ValueError):updater.check_manifest('http://invalid','2.2.0')
        m['installer_url']='https://example.com/code.zip'
        with patch.object(updater.urllib.request,'urlopen',return_value=Response(json.dumps(m).encode(),url)):
            with self.assertRaises(ValueError):updater.check_manifest(url,'2.2.0')

    def test_installer_checksum(self):
        url='https://example.com/Aion2Rader_Setup.exe'
        data=b'FAKE INSTALLER DATA - DO NOT RUN'
        rel={'installer_url':url,'sha256':hashlib.sha256(data).hexdigest()}
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'installer.exe'
            with patch.object(updater.urllib.request,'urlopen',return_value=Response(data,url)):
                self.assertEqual(updater.download_installer(rel,target),target)
            self.assertEqual(target.read_bytes(),data)
            rel['sha256']='0'*64
            target.unlink()
            with patch.object(updater.urllib.request,'urlopen',return_value=Response(data,url)):
                with self.assertRaises(ValueError):updater.download_installer(rel,target)
            self.assertFalse(target.exists())
            self.assertFalse(target.with_suffix('.part').exists())

    def test_zip_safety(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);z=p/'update.zip'
            with zipfile.ZipFile(z,'w') as f:
                f.writestr('Aion2Rader/tracker.py','print(1)')
            self.assertTrue((updater.safe_extract_package(z,p/'one')/'tracker.py').exists())
            with zipfile.ZipFile(z,'w') as f:
                f.writestr('../outside.exe','bad')
            with self.assertRaises(ValueError):updater.safe_extract_package(z,p/'two')
            self.assertFalse((p/'outside.exe').exists())

    def test_installer_worker_only_windows(self):
        if sys.platform!='win32':
            with tempfile.TemporaryDirectory() as d:
                with self.assertRaises(RuntimeError):updater.launch_windows_installer(Path(d)/'Aion2Rader_Setup.exe',d)

if __name__=='__main__':unittest.main()
