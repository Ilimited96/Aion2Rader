"""Native layout regression checks, using an isolated profile."""
import os,sys,time,tempfile
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import command_layout
from bossdata import BOSSES

with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as profile:
    os.environ['APPDATA']=profile
    app=command_layout.CommandCenter()
    try:
        app.withdraw();app.update()
        assert len(app.ov_tree.get_children())==5
        assert len(app.ov_boss_tree.get_children())==36
        for page in ['Events','World Bosses','Calendar','Settings','Updates','Map','Overview']:
            app.show_page(page);app.update()
            assert app.page==page
        app.ov_boss_search.set('Lagta');app.update()
        assert len(app.ov_boss_tree.get_children())==1
        app.ov_boss_search.set('');app.update()
        boss=next(b for b in BOSSES if b.minutes is not None)
        app.selected_boss=boss;app.var_boss_minutes.set(str(boss.minutes))
        app.mark_kill();app.update()
        assert app.boss_deadline(boss)>time.time()
        app.toggle_favorite();app.update()
        assert boss.key in app.state['favorites']
        app.toggle_favorite();app.update()
        assert boss.key not in app.state['favorites']
        app.update_visible_countdowns(time.time()+2)
        app.geometry('1200x760');app.deiconify();app.update()
        for control in [app.kill_button,app.ov_detail_timer,app.ov_boss_tree]:
            assert control.winfo_viewable()
            assert control.winfo_rootx()+control.winfo_width() <= app.winfo_rootx()+app.winfo_width()+2
            assert control.winfo_rooty()+control.winfo_height() <= app.winfo_rooty()+app.winfo_height()+2
        app.save()
        assert app.settings_file.is_file()
        app.toggle_mini();app.update()
        assert app.mini.winfo_exists()
        assert app.mini.overrideredirect()
        assert len(app.mini_rows)==2
        assert app.mini.winfo_width()==320
        assert app.mini.winfo_height()==296
        assert app.opacity_slider.winfo_rooty()+app.opacity_slider.winfo_height() <= app.mini.winfo_rooty()+app.mini.winfo_height()
        # Exercise the same bound handlers directly: Tk synthetic root coordinates
        # differ between interactive desktops and unattended Windows runners.
        # Start away from the right/bottom screen edges: resize intentionally
        # clamps at the display bounds, including on smaller Windows runners.
        app.mini.geometry('+100+100');app.update()
        old_w,old_h=app.mini.winfo_width(),app.mini.winfo_height()
        grip=app.mini_resize_grip
        app._overlay_start_resize(SimpleNamespace(x_root=500,y_root=400))
        app._overlay_resize_to(SimpleNamespace(x_root=560,y_root=440))
        grip.event_generate('<ButtonRelease-1>',rootx=560,rooty=440)
        app.update()
        assert app.mini.winfo_width()==old_w+60
        assert app.mini.winfo_height()==old_h+40
        assert app.mini_background.winfo_width()==app.mini.winfo_width()
        old_x,old_y=app.mini.winfo_x(),app.mini.winfo_y()
        edge=app.mini_move_grip
        app._overlay_start_drag(SimpleNamespace(x_root=old_x+400,y_root=old_y+100))
        app._overlay_drag_to(SimpleNamespace(x_root=old_x+360,y_root=old_y+130))
        edge.event_generate('<ButtonRelease-1>',rootx=old_x+360,rooty=old_y+130)
        app.update()
        assert app.mini.winfo_x()==old_x-40
        assert app.mini.winfo_y()==old_y+30
        assert app.mini_background.winfo_x()==app.mini.winfo_x()
        assert not app.mini_background.attributes('-disabled')
        # Empty foreground header pixels route through the background header.
        old_x,old_y=app.mini.winfo_x(),app.mini.winfo_y()
        header=app.mini_background_header
        app._overlay_background_press(SimpleNamespace(x_root=old_x+170,y_root=old_y+20))
        app._overlay_drag_to(SimpleNamespace(x_root=old_x+150,y_root=old_y+30))
        header.event_generate('<ButtonRelease-1>',rootx=old_x+150,rooty=old_y+30)
        app.update()
        assert app.mini.winfo_x()==old_x-20
        assert app.mini.winfo_y()==old_y+10
        app.refresh_mini(time.time()+1)
        assert app.mini_name.cget('text')!='Loading eventsâ€¦'
        for percent in (0,50,100):
            app.set_overlay_opacity(percent);app.update()
            assert app.mini.attributes('-alpha')==1.0
            assert abs(app.mini_background.attributes('-alpha')-percent/100)<0.01
            assert app.mini_name.cget('fg')==command_layout.TEXT
            assert app.mini.attributes('-transparentcolor')=='#010203'
            assert app.opacity_readout.cget('text')==f'{percent}%'
        app.set_overlay_opacity(0);app.update()
        app.restore_overlay_visibility();app.update()
        assert app.mini_background.attributes('-alpha')==1.0
        app.set_overlay_opacity(63)
        app.toggle_mini();app.update()
        assert app.mini is None
        app.toggle_mini();app.update()
        assert abs(app.mini_background.attributes('-alpha')-.63)<0.01
        app.set_overlay_opacity(0);app.toggle_mini();app.toggle_mini();app.update()
        assert app.mini.attributes('-alpha')==1.0
        assert app.mini_background.attributes('-alpha')==0.0
        app.toggle_mini()
        assert app.mini_background is None
        app.toggle_mini();app.update()
        close=app.mini_close_button
        app._overlay_background_press(SimpleNamespace(x_root=close.winfo_rootx()+2,y_root=close.winfo_rooty()+2))
        app.update()
        assert app.mini is None
        assert app.mini_background is None
        print('PASS: navigation, schedules, 36 bosses, search, boss timers, favorites, countdown and settings')
    finally:
        for after in app.tk.call('after','info'):
            app.after_cancel(after)
        app.destroy()
