import tempfile,zipfile,io,sys,os,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from bossdata import BOSSES,BY_KEY
from updater import version_tuple,safe_extract_package,https_url
from engine import occurrences,REGIONS
from alerts import events_just_started
assert len(BOSSES)==36
assert len([b for b in BOSSES if b.region=='Verteron'])==24
assert len([b for b in BOSSES if b.region=='Eltnen'])==12
assert not any(b.region in ('Altgard','Morheim') for b in BOSSES)
assert version_tuple('2.1')>version_tuple('2.0.1')
assert https_url('https://github.com/p/r')
assert not https_url('http://bad.test')
now=time.time();a=occurrences('Europe (EU)',now,1)
assert a and all('when' in e for e in a)
assert len(events_just_started([{'when':100,'id':'abc'}],99,101))==1
with tempfile.TemporaryDirectory() as td:
 z=Path(td)/'bad.zip'
 with zipfile.ZipFile(z,'w') as f:f.writestr('../outside.py','bad')
 try:safe_extract_package(z,Path(td)/'out')
 except ValueError:pass
 else:raise AssertionError('unsafe ZIP escaped')
 assert not (Path(td)/'outside.py').exists()
 z=Path(td)/'ok.zip'
 with zipfile.ZipFile(z,'w') as f:
  f.writestr('Aion2Rader/tracker.py','print(1)')
  f.writestr('Aion2Rader/engine.py','print(2)')
 result=safe_extract_package(z,Path(td)/'out')
 assert (result/'tracker.py').exists()
print('All logic tests passed')
