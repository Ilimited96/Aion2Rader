"""Prepare a release.json for an uploaded Inno Setup EXE.

Usage:
 python publish_release.py --repository OWNER/REPO --installer installer/Aion2Rader_Setup_v2.2.0.exe
Then upload the EXE and release.json to the same public GitHub release.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from updater import github_latest_manifest, sha256_file


def make_manifest(repository, version, installer):
    github_latest_manifest(repository)
    path=Path(installer)
    if not path.is_file() or path.suffix.lower()!='.exe':
        raise ValueError('Build the Windows Setup EXE before creating the release manifest')
    if not path.name.startswith('Aion2Rader_Setup'):
        raise ValueError('Expected an Aion2Rader Setup EXE')
    return {'version':version,
            'installer_url':f'https://github.com/{repository}/releases/download/v{version}/{path.name}',
            'sha256':sha256_file(path),
            'notes':'Aion2Rader Update V'+version+' — refined layouts, compact transparent-background overlay, and in-app boss maps with clearer clickable skulls. Settings and favorites are retained.'}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repository',required=True,help='OWNER/REPO')
    ap.add_argument('--version',default='2.3.0')
    ap.add_argument('--installer',default='installer/Aion2Rader_Setup_v2.3.0.exe')
    ap.add_argument('--out',default='installer/release.json')
    args=ap.parse_args()
    from updater import version_tuple
    version_tuple(args.version)
    info=make_manifest(args.repository,args.version,args.installer)
    p=Path(args.out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    print('Created:',p)
    print('After uploading the setup EXE and release.json to GitHub Releases, enter this URL in Updates:')
    print(github_latest_manifest(args.repository))

if __name__=='__main__':main()
