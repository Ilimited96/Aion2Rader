"""Aion2Rader release checks and Windows installer hand-off.

Release metadata must be published by the person who controls the update URL.
A HTTPS+SHA256 check detects accidental corruption, but is not a code-signature
or a guarantee against a compromised publisher. Installation is user-approved.
"""
from __future__ import annotations
import hashlib
import json
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import urlparse

MAX_MANIFEST = 64 * 1024
MAX_INSTALLER = 350 * 1024 * 1024
MAX_ZIP = 150 * 1024 * 1024


def version_tuple(v):
    raw = str(v).strip().lstrip('vV')
    if not re.fullmatch(r'\d+(?:\.\d+){0,3}', raw):
        raise ValueError('Invalid release version')
    return tuple(int(x) for x in (raw.split('.')+['0']*4)[:4])


def https_url(url):
    p = urlparse(str(url))
    return p.scheme == 'https' and bool(p.hostname) and not p.username and not p.password


def github_latest_manifest(repository):
    """Create a URL only for an explicit owner/repository; no invented host."""
    repo = repository.strip().strip('/')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('GitHub repository must look like OWNER/REPOSITORY')
    if '..' in repo:
        raise ValueError('Invalid repository')
    return f'https://github.com/{repo}/releases/latest/download/release.json'


def check_manifest(url, current_version):
    if not https_url(url):
        raise ValueError('The update manifest must use HTTPS')
    req = urllib.request.Request(url, headers={'User-Agent':'Aion2Rader/2.2'})
    with urllib.request.urlopen(req, timeout=15) as response:
        if not https_url(response.geturl()):
            raise ValueError('Update manifest redirect is not HTTPS')
        payload = response.read(MAX_MANIFEST + 1)
    if len(payload) > MAX_MANIFEST:
        raise ValueError('Manifest too large')
    obj = json.loads(payload)
    ver = str(obj['version'])
    version_tuple(ver)
    url = str(obj['installer_url'])
    sha256 = str(obj['sha256']).lower()
    if not https_url(url) or not urlparse(url).path.lower().endswith('.exe'):
        raise ValueError('This release needs an HTTPS Windows installer (.exe)')
    if not re.fullmatch(r'[a-f0-9]{64}', sha256):
        raise ValueError('Invalid SHA-256 checksum')
    return {'version': ver, 'installer_url':url, 'sha256': sha256,
            'notes':str(obj.get('notes',''))[:2000],
            'newer':version_tuple(ver)>version_tuple(current_version)}


def sha256_file(file_path):
    digest = hashlib.sha256()
    with Path(file_path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def download_installer(release, destination):
    """Download with size bound and checksum, no execution at this stage."""
    destination = Path(destination)
    url = release['installer_url']
    if not https_url(url):
        raise ValueError('HTTPS required')
    if destination.suffix.lower() != '.exe':
        raise ValueError('Installer output must have .exe extension')
    temp = destination.with_suffix('.part')
    destination.parent.mkdir(parents=True, exist_ok=True)
    size = 0
    digest = hashlib.sha256()
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'Aion2Rader/2.2'})
        with urllib.request.urlopen(req,timeout=35) as resp, temp.open('wb') as f:
            if not https_url(resp.geturl()):
                raise ValueError('Installer redirect is not HTTPS')
            while True:
                chunk = resp.read(128*1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_INSTALLER:
                    raise ValueError('Installer exceeds maximum download size')
                digest.update(chunk)
                f.write(chunk)
        if digest.hexdigest() != release['sha256'].lower():
            raise ValueError('SHA-256 mismatch. Update was rejected.')
        temp.replace(destination)
        return destination
    except Exception:
        temp.unlink(missing_ok=True)
        raise


def safe_extract_package(zip_path, dest):
    """Import a manually selected source/portable ZIP, never auto-execute."""
    dest = Path(dest)
    if dest.exists():
        raise FileExistsError(dest)
    temp = dest.with_name(dest.name+'.partial')
    if temp.exists():
        shutil.rmtree(temp)
    total = 0
    try:
        temp.mkdir(parents=True)
        with zipfile.ZipFile(zip_path) as z:
            entries = z.infolist()
            if len(entries)>450:
                raise ValueError('Too many files in ZIP')
            for item in entries:
                raw=item.filename.replace('\\','/')
                pieces=Path(raw).parts
                if not pieces or any(x in ('', '.', '..') for x in pieces) or raw.startswith('/') or ':' in pieces[0]:
                    raise ValueError('Unsafe ZIP path')
                if ((item.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError('Symlink in ZIP is not allowed')
                total += item.file_size
                if total > MAX_ZIP:
                    raise ValueError('Uncompressed ZIP size is too large')
                output=temp.joinpath(*pieces)
                if item.is_dir():
                    output.mkdir(parents=True,exist_ok=True)
                else:
                    output.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(item) as src,output.open('wb') as destfile:
                        shutil.copyfileobj(src,destfile)
        candidates=[temp, *[p for p in temp.iterdir() if p.is_dir()]]
        root=next((p for p in candidates if (p/'tracker.py').is_file() or (p/'Aion2Rader.exe').is_file()
                   or any(p.glob('Aion2Rader_Setup*.exe'))), None)
        if root is None:
            raise ValueError('ZIP has no Aion2Rader app or installer')
        if root!=temp:
            for item in list(root.iterdir()):
                shutil.move(str(item),str(temp/item.name))
            root.rmdir()
        temp.replace(dest)
    except Exception:
        if temp.exists():
            shutil.rmtree(temp)
        raise
    return dest


# A helper runs outside the application, so it can exit before Windows installer
# updates its executable. Never execute a PowerShell command assembled with file
# path interpolation: pass arguments directly as subprocess argument list.
BOOTSTRAP = r'''param(
    [Parameter(Mandatory=$true)][int]$AppPid,
    [Parameter(Mandatory=$true)][string]$Installer,
    [Parameter(Mandatory=$true)][string]$InstallDir,
    [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference = 'Stop'
try {
    for ($i=0; $i -lt 120; $i++) {
        if (-not (Get-Process -Id $AppPid -ErrorAction SilentlyContinue)) { break }
        Start-Sleep -Milliseconds 500
    }
    if (Get-Process -Id $AppPid -ErrorAction SilentlyContinue) {
        throw 'The application did not close. Update cancelled.'
    }
    $arguments = @('/SILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/CLOSEAPPLICATIONS', ('/DIR="' + $InstallDir + '"'))
    $result = Start-Process -FilePath $Installer -ArgumentList $arguments -Wait -PassThru
    if ($result.ExitCode -ne 0) {
        throw ('Installer returned exit code ' + $result.ExitCode)
    }
    $app = Join-Path $InstallDir 'Aion2Rader.exe'
    if (-not (Test-Path -LiteralPath $app -PathType Leaf)) {
        throw 'Installation completed but Aion2Rader.exe was not found.'
    }
    Start-Process -FilePath $app
} catch {
    $_.Exception.Message | Out-File -LiteralPath $LogPath -Encoding UTF8
}
'''


def installed_uninstaller():
    if sys.platform != 'win32' or not getattr(sys,'frozen',False):
        return None
    base=Path(sys.executable).resolve().parent
    uninstall=base/'unins000.exe'
    return uninstall if uninstall.is_file() else None


def default_install_dir():
    import os
    return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData/Local')))/'Programs'/'Aion2Rader'


def launch_windows_installer(installer, work_dir):
    """Start an external installer worker. Caller must close its window after success."""
    if sys.platform != 'win32':
        raise RuntimeError('The standalone installer only runs on Windows')
    installer=Path(installer).resolve()
    if installer.suffix.lower()!='.exe' or not installer.is_file():
        raise ValueError('Select the Aion2Rader Setup EXE')
    work_dir=Path(work_dir)
    work_dir.mkdir(parents=True,exist_ok=True)
    helper=work_dir/'install_after_exit.ps1'
    helper.write_text(BOOTSTRAP,encoding='utf-8-sig')
    app_uninstall=installed_uninstaller()
    install_dir=Path(sys.executable).resolve().parent if app_uninstall else default_install_dir()
    log_file=work_dir/'last_install_error.txt'
    log_file.unlink(missing_ok=True)
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
                      '-File',str(helper),'-AppPid',str(__import__('os').getpid()),
                      '-Installer',str(installer),'-InstallDir',str(install_dir),
                      '-LogPath',str(log_file)],creationflags=flags,close_fds=True)
    return log_file
