"""Only Elyos-zone field bosses, cross-checked against MetaBot's Global client tables.
Verteron respawn intervals are community estimates; Eltnen intervals unconfirmed.
"""
from dataclasses import dataclass
@dataclass(frozen=True)
class Boss:
    name: str
    region: str
    location: str
    level: int
    minutes: int | None = None
    @property
    def key(self): return f'{self.region}:{self.name}'

# region, names, locations, levels, community respawn estimates in minutes
_VERTERON = [
 ('Black Tentacle Lawa','Altamia Canyon',45,240),
 ('Centurion Demiros','Destroyed Temple Site',45,240),
 ('Divine Ansas','Contaminated Sanctum',45,360),
 ('Heretic Layla','Rock Tomb Hill',45,180),
 ('Blooming Korin','Ellun River Midstream',45,60),
 ('Kernon of the West','Western Cantas Valley',45,30),
 ('Neikel of the East','Eastern Cantas Valley',45,30),
 ("Sentinel K'nash",'Drana Processing Area',45,240),
 ('Harvest Manager Moshav','Drana Processing Area',45,180),
 ('Rotten Kutar','Ellun River Marsh',45,30),
 ('Researcher Setram','Nahid Brigade Fortress',45,360),
 ('Forest Warrior Aullamu','Aullaeu Village',45,240),
 ('Scholar Aulla','Aullaeu Village',45,120),
 ('Chaser Taulo','Forest of Exiles',45,120),
 ('Phantasm Kasia','Garden of the Illusion God',45,360),
 ('Bloodfang Pnyn','Northern Tolbas Forest',45,180),
 ('Furious Saursus','Night Dew Cave',45,180),
 ('Kusan the Mad Gladiator','Verteron Fortress Ruins',45,120),
 ('Ritualist Garshim','Verteron Fortress Ruins',45,120),
 ('Bodyguard Teegant','Destroyed Abyss Gate',45,90),
 ('Silent Dartan','Southern Altamia Highland',48,360),
 ('Soul Ruler Kashapa','Eastern Altamia Highland',48,360),
 ('High Commander Lagta','Drana Plantation',48,720),
 ('Eternal Gartua','Eternal Isle',51,720),
]
_ELTNEN = [
 ("First Test Subject K'tima",'Fractured Land',80),
 ('Rabid Nihogg','Fractured Land',80),
 ('Third Unit Captain Karkoti','Lankusis Highland',80),
 ('Deputy Commander Vivajra','Kuriullu Valley',80),
 ('Rotten Root Meltlim','Mystic Spring of Anathe',80),
 ('Three-Horned Mino','Western Dartas Plains',80),
 ('Lamphus of Agony','Eastern Dartas Plains',80),
 ('Severed Wings Zvein','Eiron Hill',80),
 ('Superbia, Sacred Beast of Life','Eltnen Barrier Tower Ruins',80),
 ('Gluttonous Egetis','Eltnen Barrier Tower Ruins',80),
 ('Agglomerated Verenom','Ruberein Highland',80),
 ('Old Boss Vigor','Ruberein Highland',80),
]
BOSSES=[*(Boss(n,'Verteron',loc,l,m) for n,loc,l,m in _VERTERON),
        *(Boss(n,'Eltnen',loc,l,None) for n,loc,l in _ELTNEN)]
BY_KEY={b.key:b for b in BOSSES}
assert len(BOSSES)==36 and len(BY_KEY)==36
MAP_LINKS={
 'Verteron':'https://metabot.gg/en/aion-2/map/verteron/field-bosses',
 'Eltnen':'https://metabot.gg/en/aion-2/map/eltnen/field-bosses',
}

# Provider marker identifiers, verified against each field-boss table's Show
# control on 2026-10-18. These identify map data; they are not guessed positions.
MAP_MARKERS={
 'Verteron:Black Tentacle Lawa':'npc:2100617',
 'Verteron:Centurion Demiros':'npc:2100708',
 'Verteron:Divine Ansas':'npc:2100718',
 'Verteron:Heretic Layla':'npc:2100582',
 'Verteron:Blooming Korin':'npc:2100141',
 'Verteron:Kernon of the West':'npc:2100050',
 'Verteron:Neikel of the East':'npc:2100003',
 "Verteron:Sentinel K'nash":'npc:2100877',
 'Verteron:Harvest Manager Moshav':'npc:2100876',
 'Verteron:Rotten Kutar':'npc:2100040',
 'Verteron:Researcher Setram':'npc:2101016',
 'Verteron:Forest Warrior Aullamu':'npc:2100989',
 'Verteron:Scholar Aulla':'npc:2100988',
 'Verteron:Chaser Taulo':'npc:2100991',
 'Verteron:Phantasm Kasia':'npc:2100661',
 'Verteron:Bloodfang Pnyn':'npc:2100178',
 'Verteron:Furious Saursus':'npc:2100177',
 'Verteron:Kusan the Mad Gladiator':'npc:2100076',
 'Verteron:Ritualist Garshim':'npc:2100077',
 'Verteron:Bodyguard Teegant':'npc:2100079',
 'Verteron:Silent Dartan':'npc:2101120',
 'Verteron:Soul Ruler Kashapa':'npc:2101122',
 'Verteron:High Commander Lagta':'npc:2101131',
 'Verteron:Eternal Gartua':'npc:2101074',
 "Eltnen:First Test Subject K'tima":'npc:2101350',
 'Eltnen:Rabid Nihogg':'npc:2101349',
 'Eltnen:Third Unit Captain Karkoti':'npc:2101600',
 'Eltnen:Deputy Commander Vivajra':'npc:2101601',
 'Eltnen:Rotten Root Meltlim':'npc:2101306',
 'Eltnen:Three-Horned Mino':'npc:2101415',
 'Eltnen:Lamphus of Agony':'npc:2101416',
 'Eltnen:Severed Wings Zvein':'npc:2101257',
 'Eltnen:Superbia, Sacred Beast of Life':'npc:2101279',
 'Eltnen:Gluttonous Egetis':'npc:2101278',
 'Eltnen:Agglomerated Verenom':'npc:2101217',
 'Eltnen:Old Boss Vigor':'npc:2101218',
}

def boss_map_url(boss):
    from urllib.parse import urlencode
    return MAP_LINKS[boss.region]+'?'+urlencode({'layers':'named','focus':MAP_MARKERS[boss.key]})
