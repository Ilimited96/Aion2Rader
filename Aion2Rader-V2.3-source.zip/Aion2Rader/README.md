# Aion2Rader 2.3.0

Unofficial AION 2 Elyos event and world-boss companion for Windows 10/11 x64.

## Install or update

Run the Setup EXE from [GitHub Releases](https://github.com/Ilimited96/Aion2Rader/releases). Existing favorites, settings and boss timers are kept. The app checks this feed when enabled:

https://github.com/Ilimited96/Aion2Rader/releases/latest/download/release.json

## This release

Refined layouts, compact floating overlay with independent background transparency, in-app boss maps, direct selection for all 36 bosses, and larger clickable skull markers. See CHANGELOG.md.

Maps use MetaBot.gg and require internet access and Microsoft Edge WebView2 Runtime. On supported Windows versions this runtime is normally installed with Microsoft Edge; if the map engine is unavailable, install the official runtime from https://developer.microsoft.com/microsoft-edge/webview2/.

The app does not read game memory, connect to game servers or automate gameplay. Boss respawn timers start from manually recorded kills and remain estimates.

## Build

Use Python 3.12 x64. Install `requirements.txt` and PyInstaller 6.22.3, then run `python -m PyInstaller --noconfirm --clean Aion2Rader.spec`. Compile Aion2Rader_Setup.iss with Inno Setup 6. The installed entry point is app.py; command_layout.py remains available as an isolated design preview.

Source validation: tests/test_logic.py, tests/test_updater_v22.py, tests/test_command_layout.py and tests/test_boss_map_navigation.py. Windows lifecycle validation runs tests/windows-lifecycle.ps1 in an isolated environment.

## Uninstall

Use Updates > Uninstall or Windows Installed apps. Windows uninstall keeps user data by default. The app offers an explicit option to remove settings too.

## Credits

Maps and marker data: MetaBot.gg. Icons: Lucide (ISC license in assets/ICONS-LICENSE.txt). Embedded viewer: tkwebview (MIT), using Microsoft WebView2. Generated decorative artwork is included in assets.
