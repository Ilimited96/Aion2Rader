"""Pure alert timing helper; no GUI dependencies."""
from __future__ import annotations


def events_just_started(events, previous, now, muted=(), seen=(), max_lateness=90):
    """Events whose start time passed since the previous poll.

    Only recent starts are announced, so the app won't replay hours of
    notifications after sleep, or show old events on application startup.
    """
    if now < previous:
        return []
    cutoff=max(previous,now-max_lateness)
    return [e for e in events
            if cutoff < e['when'] <= now
            and e['id'] not in muted
            and ('live',e['id'],e['when']) not in seen]
