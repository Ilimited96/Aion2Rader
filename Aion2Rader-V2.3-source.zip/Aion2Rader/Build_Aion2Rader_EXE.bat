@echo off
setlocal
cd /d "%~dp0"
title Aion2Rader Update V2.3 EXE Builder
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install -r requirements.txt pyinstaller==6.22.3
if errorlevel 1 goto :error
%PY% -m PyInstaller --noconfirm --clean Aion2Rader.spec
if errorlevel 1 goto :error
if exist "dist\Aion2Rader.exe" (
  echo.
  echo SUCCESS: dist\Aion2Rader.exe
  echo For a registered Windows Uninstall option, run Build_Windows_Setup.bat next.
)
pause
exit /b 0
:error
echo ERROR: EXE build failed. Ensure Python and pip are available.
pause
exit /b 1
