# Aion2Rader 2.3.0

- Refined overview, Events, World Bosses, Map and Settings layouts.
- Compact floating overlay with readable outlined text and independent background transparency.
- In-app boss maps with direct location links for all 36 Elyos bosses.
- Larger skull markers, wider click targets and corrected map layer hit testing.
- Region and boss selectors, optional map filters, and cleaner selected-event panel.
- Existing settings, favorites and kill timers are retained.

Internet and Microsoft Edge WebView2 Runtime are required for maps. The map data remains provided by MetaBot.gg. Boss timers are community estimates based on manually recorded kills.

Windows builds are unsigned. Release validation checks application startup, redesigned tabs, embedded WebView2 rendering, overlay opacity, installer handoff, retained settings and uninstall. A future-version download and confirmation through the full GUI is not part of the automated checks.
