"""Opt-in frozen release check; uses only the caller's isolated test profile."""
import json,sys
from pathlib import Path

def run(app):
    destination=Path(next(arg.split('=',1)[1] for arg in sys.argv if arg.startswith('--self-test-report=')))
    app.var_auto_updates.set(False)
    checks=[]
    def finish(ok,error=''):
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps({'ok':ok,'checks':checks,'error':error}),encoding='utf-8')
        app.destroy()
    def check():
        try:
            import tracker
            assert tracker.VERSION=='2.3.0'
            assert 'Update V2.3.0' in app.title()
            for page in ['Overview','Events','World Bosses','Calendar','Settings','Updates','Map']:
                app.show_page(page);app.update_idletasks()
            checks.append('All seven redesigned tabs and packaged artwork')
            app.toggle_mini();app.update_idletasks()
            app.set_overlay_opacity(30)
            assert app.mini.attributes('-alpha')==1.0
            assert abs(app.mini_background.attributes('-alpha')-.3)<.01
            app.toggle_mini()
            checks.append('Floating overlay and independent background opacity')
            from embedded_map import EmbeddedMap
            viewer=EmbeddedMap(app.map_host);viewer.pack(fill='both',expand=True)
            app.release_smoke_viewer=viewer
            viewer.bindjs('releaseSmokeReady',lambda value:ready(value))
            viewer.set_html('<html><body><h1 id="ready">Aion2Rader map engine ready</h1><script>setTimeout(()=>releaseSmokeReady(document.getElementById("ready").textContent),500)</script></body></html>')
            app.after(15000,lambda:finish(False,'Embedded WebView2 did not report ready'))
        except Exception as error:finish(False,repr(error))
    def ready(value):
        if value!='Aion2Rader map engine ready':return
        checks.append('Packaged WebView2 DLL, browser initialization and rendering')
        # Let the native JavaScript callback return before destroying WebView2.
        app.after(500,lambda:finish(True))
    app.after(300,check)
