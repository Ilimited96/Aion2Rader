"""Offline AION 2 Global event calculator. Standard library only.

Schedules are community-observed, NOT a live connection to the game.
Times can be shifted in app settings when a server behaves differently.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
import math
import sys

BASE = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
UTC = timezone.utc
REGIONS = {
    'Europe (EU)': 'Europe/Berlin',
    'North America East': 'America/New_York',
    'North America West': 'America/Los_Angeles',
    'South America': 'America/Sao_Paulo',
    'Asia Global': 'Asia/Seoul',
}


def zone(name: str):
    # Bundled IANA timezone snapshots work even on Windows without tzdata.
    path = BASE / 'zones' / (name.replace('/', '_') + '.tzif')
    if path.is_file():
        with path.open('rb') as file:
            return ZoneInfo.from_file(file, key=name)
    return ZoneInfo(name)


@dataclass(frozen=True)
class EventDef:
    code: str
    name: str
    category: str
    hours: tuple[int, ...]
    minute: int = 0
    weekdays: tuple[int, ...] = tuple(range(7))
    duration: int = 0
    tz_mode: str = 'server'  # or 'utc'
    detail: str = ''
    reliability: str = 'COMMUNITY'


HOURS = tuple(range(24))
DEFS = [
    EventDef('shugo', 'Shugo Festival', 'Festival', HOURS, 0, duration=10, detail='Hourly minigame. Check the in-game queue and available Shugo keys.'),
    EventDef('invasion', 'Dimensional Invasion', 'Invasion', HOURS, 30, duration=15, detail='Hourly defense event. Entry can close within a few minutes of the start.'),
    EventDef('rift', 'Spacetime Rift', 'Rift', tuple(range(2, 24, 3)), 0, duration=10, detail='Portal entry window ~10 min; the area event lasts about one hour.'),
    EventDef('kaira', 'Watcher Kaira', 'Bosses', tuple(range(1, 24, 3)), 0, duration=30, detail='Scheduled Abyss boss, Lower Reshanta; position varies.'),
    EventDef('siege', 'Artifact Siege', 'Sieges', (21,), 0, (0, 3, 5), 30, detail='Abyss artifact battle; reported 21:00 on regional server clock.', reliability='UNCONFIRMED HOUR'),
    EventDef('executors', 'Siege Bosses: Executors & Executioners', 'Bosses', (21,), 30, (0, 3, 5), 30, detail='Executor Argo, Kaira and Tamasa; Executioner Dramos, Ravager Marakha and Turncoat Ducal.', reliability='UNCONFIRMED HOUR'),
    EventDef('nahma', 'Guardian Lord Nahma', 'Bosses', (21,), 0, (4, 6), 30, detail='Guardian Lord Nahma / Enraged Guardian Lord Nahma in the Abyss.', reliability='UNCONFIRMED HOUR'),
    EventDef('arena_am', 'Arena of Tactics - daytime window', 'PvP', (11,), 0, duration=180, detail='Reported 10v10 matchmaking window 11:00-14:00 server time.', reliability='TENTATIVE'),
    EventDef('arena_pm', 'Arena of Tactics - evening window', 'PvP', (19,), 0, duration=120, detail='Reported 10v10 matchmaking window 19:00-21:00 server time.', reliability='TENTATIVE'),
    EventDef('daily', 'Daily Reset', 'Resets', (7,), 0, duration=0, tz_mode='utc', detail='Daily quests, dungeon entries, and other daily limits refresh at 07:00 UTC.'),
    EventDef('weekly', 'Weekly Reset', 'Resets', (7,), 0, (2,), 0, 'utc', 'Weekly quests, instances and other weekly limits refresh at 07:00 UTC Wednesday.'),
    EventDef('ascension', 'Ascension Trial Rotation', 'Resets', (7,), 0, (2,), 0, 'utc', 'Dungeon rotation changes with the Wednesday weekly reset.'),
]

# These are *deadline reminders*, not server-observed live events.
DEADLINES = [
    ('pass_event', 'Daeva Pass event period ends', 'Deadline', '2026-10-28T07:00:00+00:00', 'Community-published event-period endpoint; verify in game.'),
    ('season1', 'Abyss / Daeva Pass Season 1 ends', 'Deadline', '2026-12-16T07:00:00+00:00', 'Community client-data endpoint; verify official announcements.'),
]

# Named field bosses, from public community tables. Respawn minutes are
# estimates only, and some community sources disagree strongly.
# Numbers are default MAX of reported range where a range exists.
ELYOS_BOSSES = {
    'Kernon of the West':30, 'Neikel of the East':30, 'Rotten Kutar':30,
    'Blooming Korin':60, 'Bodyguard Teegant':90, 'Kusan the Mad Gladiator':120,
    'Ritualist Garshim':120, 'Scholar Aulla':120, 'Chaser Taulo':120,
    'Forest Warrior Aullamu':240, 'Black Tentacle Lawa':240, 'Centurion Demiros':240,
    "Sentinel K'nash":240, 'Bloodfang Pnyn':180, 'Furious Saursus':180,
    'Heretic Layla':180, 'Harvest Manager Moshav':180, 'Researcher Setram':360,
    'Divine Ansas':360, 'Phantasm Kasia':360, 'Silent Dartan':360,
    'Soul Ruler Kashapa':360, 'High Commander Lagta':720, 'Eternal Gartua':720,
}
ASMO_BOSSES = {
    'Black Warrior Aed':30, 'Faithful Rajit':30, 'Melted Danar':60,
    'Berserker Vargor':60, 'Blood Warrior Lannar':90, 'Predator Garsan':120,
    'Deceiver Trid':120, 'Blue Wave Kelpina':120, 'High Overseer Nutah':120,
    'Advisor Resana':180, 'Special Operations Leader Linx':180,
    'Addicted Hardirun':180, 'Veteran Shujakan':180,
    'Desecrator Newbold':240, 'Specter Archon Axios':240,
    'Executioner Barthien':240, 'Visionary Karuka':240,
    'Drakan Battalion Weapon Guruta':360, 'Dark Shadow Vishwada':360,
    'Sharp Shylak':360, 'Silent Dartan':360, 'Soul Ruler Kashapa':360,
    'High Commander Lagta':720, 'Immortal Gartua':720,
}
BOSSES = {**{'Elyos / Verteron - '+name: mins for name, mins in ELYOS_BOSSES.items()},
          **{'Asmodian / Altgard - '+name: mins for name, mins in ASMO_BOSSES.items()}}


def valid_wall(day, hour, minute, tz):
    """Return wall-clock timestamps. Skip DST nonexistent hours; handle repeats."""
    results = set()
    for fold in (0, 1):
        dt = datetime(day.year, day.month, day.day, hour, minute, tzinfo=tz, fold=fold)
        ts = dt.timestamp()
        rt = datetime.fromtimestamp(ts, tz)
        if (rt.date() == day and rt.hour == hour and rt.minute == minute):
            results.add(round(ts))
    return sorted(results)


def occurrences(region='Europe (EU)', now=None, horizon_days=7, shifts=None,
                extras=None, kills=None):
    """All timestamps (UTC unix seconds) from 1 day ago to future horizon.

    It yields dicts {id, name, category, when, duration, detail, reliability}.
    """
    if region not in REGIONS:
        region = 'Europe (EU)'
    shifts = shifts or {}
    extras = extras or []
    kills = kills or []
    now = float(now if now is not None else datetime.now(UTC).timestamp())
    out = []
    end = now + horizon_days * 86400
    for ev in DEFS:
        tz = UTC if ev.tz_mode == 'utc' else zone(REGIONS[region])
        base_date = datetime.fromtimestamp(now, tz).date() - timedelta(days=1)
        for di in range(horizon_days+4):
            day = base_date + timedelta(days=di)
            if day.weekday() not in ev.weekdays:
                continue
            for hour in ev.hours:
                for ts in valid_wall(day, hour, ev.minute, tz):
                    ts += int(shifts.get(ev.code, 0)) * 60
                    if now-86400 <= ts <= end:
                        out.append({'id':ev.code, 'name':ev.name, 'category':ev.category,
                                    'when':ts, 'duration':ev.duration*60, 'detail':ev.detail,
                                    'reliability':ev.reliability, 'source':'community'})
    for code,name,category,iso,detail in DEADLINES:
        ts = datetime.fromisoformat(iso).timestamp()
        if now-86400 <= ts <= end:
            out.append({'id':code,'name':name,'category':category,'when':ts,'duration':0,
                        'detail':detail,'reliability':'COMMUNITY','source':'deadline'})
    for item in extras:
        try:
            ts = int(float(item['when']))
            if now-86400 <= ts <= end:
                out.append({'id':'user:'+str(item['id']),'name':str(item['name'])[:100],
                            'category':'Personal','when':ts,'duration':0,
                            'detail':str(item.get('detail','User-added event'))[:300],
                            'reliability':'YOUR EVENT','source':'personal'})
        except (ValueError, TypeError, KeyError, OverflowError):
            continue
    for item in kills:
        try:
            ts = float(item['kill']) + int(float(item['minutes']))*60
            if now-86400 <= ts <= end:
                out.append({'id':'kill:'+str(item['id']),'name':str(item['name'])[:100],
                            'category':'Field Boss','when':ts,'duration':0,
                            'detail':'Estimated respawn after your recorded kill. Check Map > Exploration > Field Boss for actual status.',
                            'reliability':'MANUAL ESTIMATE','source':'kill'})
        except (ValueError, TypeError, KeyError, OverflowError):
            continue
    return sorted(out, key=lambda e:(e['when'],e['name']))


def stamp(ts):
    """Local computer time; uses Windows' correct DST rules on Windows."""
    return datetime.fromtimestamp(ts).strftime('%a %d %b  %H:%M')


def clock(remaining):
    secs = max(0, int(math.ceil(remaining)))
    days, left = divmod(secs,86400)
    h, left = divmod(left,3600)
    m, s = divmod(left,60)
    return (f'{days}d {h:02}:{m:02}:{s:02}' if days else f'{h:02}:{m:02}:{s:02}')


def ics(events, pre_minutes=10):
    def utc_text(ts):
        return datetime.fromtimestamp(ts,UTC).strftime('%Y%m%dT%H%M%SZ')
    def escape(x):
        return str(x).replace('\\','\\\\').replace('\n','\\n').replace(';','\\;').replace(',','\\,')
    lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//AION2 Event Radar//Local Tracker//EN',
             'CALSCALE:GREGORIAN','METHOD:PUBLISH']
    for ev in events:
        ts = ev['when']
        lines += ['BEGIN:VEVENT',f'UID:{ev["id"]}-{int(ts)}@aion2-event-radar.local',
                  f'DTSTAMP:{utc_text(datetime.now(UTC).timestamp())}',
                  f'DTSTART:{utc_text(ts)}',f'DTEND:{utc_text(ts+max(60,ev["duration"]))}',
                  f'SUMMARY:{escape("AION 2 - "+ev["name"])}',
                  f'DESCRIPTION:{escape(ev["detail"]+" | Community schedule, verify in game.")}']
        if pre_minutes:
            lines += ['BEGIN:VALARM','ACTION:DISPLAY',
                      f'DESCRIPTION:{escape(ev["name"]+" begins soon")}',
                      f'TRIGGER:-PT{int(pre_minutes)}M','END:VALARM']
        lines += ['END:VEVENT']
    lines += ['END:VCALENDAR']
    # RFC 5545 line folding, 75 octets per line (ASCII mostly; UTF-8 aware)
    result=[]
    for line in lines:
        current=''
        for ch in line:
            if len((current+ch).encode('utf-8')) > 73:
                result.append(current)
                current=' '+ch
            else:
                current+=ch
        result.append(current)
    return '\r\n'.join(result)+'\r\n'
