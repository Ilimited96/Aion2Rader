"""Windows WebView2 map surface. No Python bridge is exposed to remote pages."""
from pathlib import Path
import sys

vendor=Path(__file__).resolve().parent/'vendor'
if vendor.is_dir():
    sys.path.insert(0,str(vendor))

from tkwebview import TkWebview


MAP_ONLY_SCRIPT = r"""
(() => {
  if (location.hostname !== 'metabot.gg') return;
  const css = `
    html,body {background:#071827!important; margin:0!important; overflow:hidden!important;}
    body {visibility:hidden!important;}
    [data-aion-outside-map] {display:none!important;}
    [data-aion-map-path] {overflow:visible!important; transform:none!important;
      filter:none!important; perspective:none!important; contain:none!important;
      content-visibility:visible!important; clip-path:none!important;}
    [data-aion-map-only], [data-aion-map-only] * {visibility:visible!important;}
    [data-aion-map-only] {position:fixed!important; inset:0!important;
      width:100vw!important; height:100vh!important; max-width:none!important;
      margin:0!important; border:0!important; border-radius:0!important;
      display:flex!important; flex-direction:column!important; z-index:2147483646!important;}
    [data-aion-map-only] > [class*='_body'] {flex:1!important; min-height:0!important; height:auto!important;}
    [data-aion-map-only] [class*='_stage'] {flex:1!important; min-height:0!important; height:100%!important;}
    [data-aion-map-only] .leaflet-container {height:100%!important; width:100%!important;}
    [data-aion-map-only]:not([data-aion-filters='open']) > [class*='_body'] {grid-template-columns:minmax(0,1fr)!important;}
    [data-aion-map-only]:not([data-aion-filters='open']) > [class*='_body'] > aside {display:none!important;}
  `;
  function isolate() {
    if (!document.getElementById('aion-map-style') && document.documentElement) {
      const style=document.createElement('style');style.id='aion-map-style';
      style.textContent=css;document.documentElement.appendChild(style);
    }
    // The provider lazy-loads Leaflet only after the map enters the viewport.
    // Reveal its server-rendered map shell first; waiting for Leaflet here
    // would leave the whole page hidden and prevent initialization forever.
    const map=document.querySelector('.leaflet-container, [class$="_map"]');
    const viewer=map && map.closest('[class*="_client"]');
    if (!viewer) return;
    const first=!viewer.hasAttribute('data-aion-map-only');
    viewer.setAttribute('data-aion-map-only','');
    // Keep the useful location search; remove redundant website actions.
    viewer.querySelectorAll('button').forEach(button=>{
      if (['collection route','copy link'].includes(button.textContent.trim().toLowerCase()))
        button.style.display='none';
    });
    for (let node=viewer;node.parentElement && node!==document.body;node=node.parentElement) {
      node.parentElement.setAttribute('data-aion-map-path','');
      for (const sibling of node.parentElement.children) {
        if (sibling!==node && sibling.tagName!=='STYLE' && sibling.tagName!=='SCRIPT')
          sibling.setAttribute('data-aion-outside-map','');
      }
    }
    if (first) setTimeout(()=>window.dispatchEvent(new Event('resize')),150);
  }
  let queued=false;
  new MutationObserver(()=>{
    if (!queued) {queued=true;setTimeout(()=>{queued=false;isolate();},80);}
  }).observe(document,{childList:true,subtree:true});
  document.addEventListener('DOMContentLoaded',isolate);
  isolate();
})();
"""

MARKER_SCRIPT = r"""
(() => {
  if (location.hostname !== 'metabot.gg') return;
  let leaflet;
  function attach(L) {
    if (!L || !L.Map || L.Map.prototype._aionAttached) return;
    L.Map.prototype._aionAttached=true;
    L.Map.addInitHook(function() {
      const map=this;
      map.getContainer().__aionMap=map;
      let pending=false;
      function refresh() {
        pending=false;
        const interactiveCanvases=new Set();
        map.eachLayer(layer=>{
          const renderer=layer._renderer;
          if (renderer && layer.options.interactive!==false && renderer._container)
            interactiveCanvases.add(renderer._container);
          const src=layer.options.img && layer.options.img.src;
          if (!src || !/\/mapicons\/(named|boss)\.webp(?:\?|$)/.test(src)) return;
          if (!layer._aionBoss) {
            layer._aionBoss=true;
            const draw=layer._updatePath;
            layer._updatePath=function() {
              const ctx=this._renderer && this._renderer._ctx;
              if (!ctx || !this._renderer._drawing || this._empty()) return draw.call(this);
              ctx.save();
              ctx.beginPath();ctx.arc(this._point.x,this._point.y,this._radius+2,0,2*Math.PI);
              ctx.fillStyle='#071321';ctx.fill();
              ctx.strokeStyle='#F1CA78';ctx.lineWidth=2;ctx.stroke();
              ctx.shadowColor='#000';ctx.shadowBlur=3;
              draw.call(this);ctx.restore();
            };
            const contains=layer._containsPoint;
            layer._containsPoint=function(point) {
              return this._point ? point.distanceTo(this._point)<=Math.max(24,this._radius+4) : contains.call(this,point);
            };
          }
          // Keep the skull readable when the provider scales icons down at
          // lower zoom levels. The click target is at least 48 pixels wide.
          if (layer.getRadius()<20) layer.setRadius(20);
        });
        // The provider draws noninteractive zone boundaries in another canvas
        // above the boss canvas. Let mouse events reach the marker renderer.
        map.getPane('overlayPane').querySelectorAll('canvas').forEach(canvas=>{
          canvas.style.pointerEvents=interactiveCanvases.has(canvas)?'auto':'none';
        });
      }
      function schedule() {if (!pending) {pending=true;requestAnimationFrame(refresh);}}
      map.on('layeradd layerremove zoomend',schedule);
      schedule();
    });
  }
  Object.defineProperty(window,'L',{configurable:true,get:()=>leaflet,set:value=>{leaflet=value;attach(value);}});
})();
"""


class EmbeddedMap(TkWebview):
    def __init__(self,parent):
        super().__init__(parent)
        self.init(MAP_ONLY_SCRIPT)
        self.init(MARKER_SCRIPT)

    def destroy(self):
        # The upstream Frame wrapper does not release its native controller.
        # Dispose it before Tk destroys the parent HWND on tab changes/exit.
        native=getattr(self,'webview',None)
        if native is not None:
            native.destroy()
        super().destroy()
