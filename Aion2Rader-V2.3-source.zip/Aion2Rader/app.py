"""Installed application entry point; uses the existing user settings."""
import sys

if '--use-settings' not in sys.argv:sys.argv.append('--use-settings')
from command_layout import CommandCenter

if __name__=='__main__':
    app=CommandCenter()
    if '--self-test' in sys.argv:
        from release_smoke import run
        run(app)
    app.mainloop()
