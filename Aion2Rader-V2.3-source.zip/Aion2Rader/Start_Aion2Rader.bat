@echo off
setlocal
cd /d "%~dp0"
title Aion2Rader - Update V2.3
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 app.py
) else (
  python app.py
)
if errorlevel 1 (
  echo Could not start Aion2Rader. Install Python 3.11+ from python.org.
  pause
)
endlocal
